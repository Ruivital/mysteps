#!/usr/bin/env bash
# Configura Java 17, Android SDK (linha de comandos) e Gradle 8.7 e compila o APK debug.
# Uso:  ./setup_and_build.sh            -> compila
#       ./setup_and_build.sh --install  -> compila e instala via adb (telemóvel ligado por USB)
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SDK_DIR="${ANDROID_SDK_ROOT:-$HOME/android-sdk}"
GRADLE_VERSION="8.7"
GRADLE_DIST_DIR="$HOME/.local/share/gradle-dist"
CMDLINE_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
GRADLE_URL="https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"
INSTALL_APK=0
[[ "${1:-}" == "--install" ]] && INSTALL_APK=1

log() { printf '\n\033[1;32m==> %s\033[0m\n' "$*"; }
die() { printf '\033[1;31mERRO: %s\033[0m\n' "$*" >&2; exit 1; }

[[ "$(uname -m)" == "x86_64" ]] || die "Este script requer Linux x86_64 (as build-tools do Android não existem para ARM)."

# ---------------------------------------------------------------- 1. Pacotes do sistema
log "1/6 Verificar pacotes do sistema (JDK 17, wget, unzip)"
missing=()
command -v wget  >/dev/null 2>&1 || missing+=(wget)
command -v unzip >/dev/null 2>&1 || missing+=(unzip)
[[ -d /usr/lib/jvm/java-17-openjdk-amd64 ]] || missing+=(openjdk-17-jdk)
if (( ${#missing[@]} > 0 )); then
    echo "A instalar: ${missing[*]} (pede a palavra-passe sudo)"
    sudo apt-get update
    sudo apt-get install -y "${missing[@]}"
fi
if [[ -d /usr/lib/jvm/java-17-openjdk-amd64 ]]; then
    export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
    export PATH="$JAVA_HOME/bin:$PATH"
fi
command -v javac >/dev/null 2>&1 || die "javac não encontrado."
JAVA_MAJOR="$(javac -version 2>&1 | awk '{print $2}' | cut -d. -f1)"
(( JAVA_MAJOR >= 17 )) || die "É necessário JDK 17 ou superior (encontrado: $JAVA_MAJOR)."
echo "JDK $JAVA_MAJOR OK"

# ---------------------------------------------------------------- 2. Android command-line tools
log "2/6 Android command-line tools"
SDKMANAGER="$SDK_DIR/cmdline-tools/latest/bin/sdkmanager"
if [[ ! -x "$SDKMANAGER" ]]; then
    mkdir -p "$SDK_DIR/cmdline-tools"
    tmp="$(mktemp -d)"
    wget -q --show-progress -O "$tmp/cmdline-tools.zip" "$CMDLINE_URL"
    unzip -q "$tmp/cmdline-tools.zip" -d "$tmp"
    rm -rf "$SDK_DIR/cmdline-tools/latest"
    mv "$tmp/cmdline-tools" "$SDK_DIR/cmdline-tools/latest"
    rm -rf "$tmp"
fi

# ---------------------------------------------------------------- 3. Pacotes do SDK
log "3/6 Licenças e pacotes do SDK (platform-tools, android-34, build-tools 34.0.0)"
yes 2>/dev/null | "$SDKMANAGER" --sdk_root="$SDK_DIR" --licenses >/dev/null || true
"$SDKMANAGER" --sdk_root="$SDK_DIR" "cmdline-tools;latest" "platform-tools" "platforms;android-34" "build-tools;34.0.0"

# ---------------------------------------------------------------- 4. Gradle
log "4/6 Gradle $GRADLE_VERSION"
GRADLE_BIN="$GRADLE_DIST_DIR/gradle-${GRADLE_VERSION}/bin/gradle"
if [[ ! -x "$GRADLE_BIN" ]]; then
    mkdir -p "$GRADLE_DIST_DIR"
    tmp="$(mktemp -d)"
    wget -q --show-progress -O "$tmp/gradle.zip" "$GRADLE_URL"
    unzip -q "$tmp/gradle.zip" -d "$GRADLE_DIST_DIR"
    rm -rf "$tmp"
fi

# ---------------------------------------------------------------- 5. Compilar
log "5/6 A compilar (assembleDebug) — a primeira vez descarrega dependências"
export ANDROID_HOME="$SDK_DIR"
export ANDROID_SDK_ROOT="$SDK_DIR"
echo "sdk.dir=$SDK_DIR" > "$PROJECT_DIR/local.properties"
cd "$PROJECT_DIR"
"$GRADLE_BIN" --console=plain assembleDebug

APK_SRC="$PROJECT_DIR/app/build/outputs/apk/debug/app-debug.apk"
[[ -f "$APK_SRC" ]] || die "APK não foi gerado."
cp "$APK_SRC" "$PROJECT_DIR/MySteps-debug.apk"

# ---------------------------------------------------------------- 6. Instalar (opcional)
log "6/6 Concluído"
echo "APK: $PROJECT_DIR/MySteps-debug.apk"
ADB="$SDK_DIR/platform-tools/adb"
if (( INSTALL_APK )); then
    "$ADB" devices
    "$ADB" install -r "$PROJECT_DIR/MySteps-debug.apk"
else
    echo "Para instalar:  $ADB install -r $PROJECT_DIR/MySteps-debug.apk"
fi
