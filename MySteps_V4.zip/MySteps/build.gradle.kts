// Plugins declarados na raiz (versões fixas); aplicados no módulo :app
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    // KSP tem de corresponder à versão do Kotlin (1.9.24-1.0.20)
    id("com.google.devtools.ksp") version "1.9.24-1.0.20" apply false
}
