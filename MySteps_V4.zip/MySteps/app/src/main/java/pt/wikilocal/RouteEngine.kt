package pt.wikilocal

import org.osmdroid.util.GeoPoint
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

object GeoMath {
    private const val EARTH_RADIUS = 6371008.8

    class Projection(val perp: Double, val t: Double, val point: GeoPoint)

    /** Distância (m) entre dois pontos — Haversine. */
    fun distance(a: GeoPoint, b: GeoPoint): Double {
        val lat1 = Math.toRadians(a.latitude)
        val lat2 = Math.toRadians(b.latitude)
        val dLat = lat2 - lat1
        val dLon = Math.toRadians(b.longitude - a.longitude)
        val h = sin(dLat / 2).pow(2) + cos(lat1) * cos(lat2) * sin(dLon / 2).pow(2)
        return 2 * EARTH_RADIUS * asin(min(1.0, sqrt(h)))
    }

    /** Rumo inicial (0..360, graus a partir do norte, sentido horário) de [a] para [b]. */
    fun bearing(a: GeoPoint, b: GeoPoint): Double {
        val p1 = Math.toRadians(a.latitude)
        val p2 = Math.toRadians(b.latitude)
        val dl = Math.toRadians(b.longitude - a.longitude)
        val y = sin(dl) * cos(p2)
        val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }

    /** Diferença angular (a - b) normalizada para (-180, 180]. Positivo = rodar para a direita. */
    fun angleDiff(a: Double, b: Double): Double = ((a - b + 540.0) % 360.0) - 180.0

    /** Projeção de [p] no segmento a-b (plano local, suficiente para segmentos curtos). */
    fun project(p: GeoPoint, a: GeoPoint, b: GeoPoint): Projection {
        val kx = 111320.0 * cos(Math.toRadians(a.latitude))
        val ky = 110540.0
        val abx = (b.longitude - a.longitude) * kx
        val aby = (b.latitude - a.latitude) * ky
        val apx = (p.longitude - a.longitude) * kx
        val apy = (p.latitude - a.latitude) * ky
        val len2 = abx * abx + aby * aby
        val t = if (len2 > 0.0) ((apx * abx + apy * aby) / len2).coerceIn(0.0, 1.0) else 0.0
        val dx = apx - t * abx
        val dy = apy - t * aby
        return Projection(
            sqrt(dx * dx + dy * dy),
            t,
            GeoPoint(
                a.latitude + (b.latitude - a.latitude) * t,
                a.longitude + (b.longitude - a.longitude) * t
            )
        )
    }
}

/**
 * Motor de percursos.
 *
 * O percurso ativo é definido por um ponto de início S (índice no ficheiro) e por um sentido:
 *   normal  -> de S até ao fim do ficheiro
 *   inverso -> de S até ao início do ficheiro (ao contrário)
 * Também deteta as curvas do percurso para as indicações de voz.
 */
class RouteEngine {

    data class Status(
        val distanceToRoute: Double,
        val remaining: Double,
        val progress: Double,
        val offRoute: Boolean,
        val arrived: Boolean,
        val distanceAlong: Double = 0.0,
        val nearestPoint: GeoPoint? = null,
        val remainingGain: Double = 0.0,
        val remainingLoss: Double = 0.0
    )

    /** Curva: [distance] ao longo do percurso ativo (m); [angle] > 0 = direita, < 0 = esquerda. */
    data class Maneuver(val distance: Double, val angle: Double)

    class RouteHit(val vertexIndex: Int, val distance: Double, val point: GeoPoint)

    private class Hit(val perp: Double, val along: Double, val point: GeoPoint)

    companion object {
        const val NEAR_METERS = 300.0
        const val ARRIVED_METERS = 25.0
        const val SEARCH_WINDOW = 150
        const val TURN_MIN_DEG = 45.0        // curvas suaves de trilho não geram avisos
        const val RESAMPLE_STEP = 10.0
        const val TURN_WINDOW = 4            // 40 m antes / 40 m depois
        const val TURN_MERGE_METERS = 40.0

        /** Tolerância ao percurso: aumenta quando o GPS é pior (mata, encostas). Entre 30 e 80 m. */
        fun routeTolerance(accuracy: Double): Double = (1.5 * accuracy + 15.0).coerceIn(30.0, 80.0)
    }

    var name: String = ""
        private set
    var reversed: Boolean = false
        private set

    private var original: List<GeoPoint> = emptyList()
    private var startChosen = false
    private var startIdx = 0
    private var path: List<GeoPoint> = emptyList()
    private var cum = DoubleArray(0)
    private var progressIdx = 0
    private var fullMeters = 0.0
    private var maneuvers: List<Maneuver> = emptyList()
    private var gainCum = DoubleArray(0)
    private var lossCum = DoubleArray(0)

    /** Subida/descida totais do percurso completo (0 se o ficheiro não tiver elevação). */
    var routeGain = 0.0
        private set
    var routeLoss = 0.0
        private set

    val isLoaded: Boolean get() = original.size >= 2
    val fullPath: List<GeoPoint> get() = original
    val activePath: List<GeoPoint> get() = path
    val totalMeters: Double get() = fullMeters
    val startPoint: GeoPoint? get() = if (isLoaded) original[effectiveStart()] else null

    fun load(routeName: String, points: List<GeoPoint>) {
        name = routeName
        original = points.toList()
        reversed = false
        startChosen = false
        startIdx = 0
        fullMeters = 0.0
        for (i in 1 until original.size) fullMeters += GeoMath.distance(original[i - 1], original[i])
        val (g, l) = elevationProfile(original)
        routeGain = g.lastOrNull() ?: 0.0
        routeLoss = l.lastOrNull() ?: 0.0
        rebuild()
    }

    fun toggleReverse(): Boolean {
        if (!isLoaded) return reversed
        reversed = !reversed
        rebuild()
        return reversed
    }

    /** Define o início no vértice mais próximo de [p]. Devolve a distância (m) a esse vértice. */
    fun setStartNearest(p: GeoPoint): Double {
        if (!isLoaded) return 0.0
        var best = 0
        var bestD = Double.MAX_VALUE
        for (i in original.indices) {
            val d = GeoMath.distance(p, original[i])
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        startIdx = best
        startChosen = true
        rebuild()
        return bestD
    }

    fun resetStart() {
        startChosen = false
        rebuild()
    }

    fun resetProgress() {
        progressIdx = 0
    }

    /** Ponto do percurso completo mais próximo de [p] (projeção em segmentos). */
    fun nearestOnRoute(p: GeoPoint): RouteHit? {
        if (!isLoaded) return null
        var bestD = Double.MAX_VALUE
        var bestPt = original[0]
        var bestI = 0
        for (i in 0 until original.size - 1) {
            val pr = GeoMath.project(p, original[i], original[i + 1])
            if (pr.perp < bestD) {
                bestD = pr.perp
                bestPt = pr.point
                bestI = if (pr.t < 0.5) i else i + 1
            }
        }
        return RouteHit(bestI, bestD, bestPt)
    }

    fun nextManeuver(distAlong: Double): Maneuver? =
        maneuvers.firstOrNull { it.distance > distAlong - 3.0 }

    /** Ponto do percurso ativo cerca de [meters] à frente de [distAlong]. */
    fun pointAhead(distAlong: Double, meters: Double): GeoPoint? {
        if (path.isEmpty()) return null
        val target = distAlong + meters
        for (i in progressIdx until path.size) if (cum[i] >= target) return path[i]
        return path.last()
    }

    fun update(pos: GeoPoint, accuracy: Double = 0.0): Status {
        val tolerance = routeTolerance(accuracy)
        val n = path.size
        if (n == 0) return Status(0.0, 0.0, 0.0, offRoute = false, arrived = false)

        var idx = nearestIndex(pos, progressIdx, min(n - 1, progressIdx + SEARCH_WINDOW))
        var hit = refine(pos, idx)
        if (hit.perp > tolerance) {
            val g = nearestIndex(pos, 0, n - 1)
            val h2 = refine(pos, g)
            if (h2.perp < hit.perp) {
                idx = g
                hit = h2
            }
        }
        val off = hit.perp > tolerance
        if (!off) progressIdx = idx

        val total = cum[n - 1]
        val along = hit.along.coerceIn(0.0, total)
        val remaining = total - along
        val progress = if (total > 0) along / total else 1.0
        val arrivedRadius = maxOf(ARRIVED_METERS, accuracy).coerceAtMost(40.0)
        val arrived = remaining <= 60.0 + arrivedRadius && GeoMath.distance(pos, path[n - 1]) <= arrivedRadius
        val rg = if (gainCum.size == n) gainCum[n - 1] - gainCum[idx] else 0.0
        val rl = if (lossCum.size == n) lossCum[n - 1] - lossCum[idx] else 0.0
        return Status(hit.perp, remaining, progress, off, arrived, along, hit.point, rg, rl)
    }

    // ------------------------------------------------------------------ interno

    private fun effectiveStart(): Int =
        if (startChosen) startIdx else if (reversed) original.lastIndex else 0

    private fun rebuild() {
        if (original.isEmpty()) {
            path = emptyList()
            cum = DoubleArray(0)
            progressIdx = 0
            maneuvers = emptyList()
            gainCum = DoubleArray(0)
            lossCum = DoubleArray(0)
            return
        }
        val s = effectiveStart()
        path = if (!reversed) original.subList(s, original.size).toList()
        else original.subList(0, s + 1).reversed()
        cum = DoubleArray(path.size)
        for (i in 1 until path.size) cum[i] = cum[i - 1] + GeoMath.distance(path[i - 1], path[i])
        progressIdx = 0
        maneuvers = detectManeuvers()
        val (g, l) = elevationProfile(path)
        gainCum = g
        lossCum = l
    }

    /** Subida/descida acumuladas ponto a ponto (suavizadas, limiar 3 m). Sem altitudes -> zeros. */
    private fun elevationProfile(pts: List<GeoPoint>): Pair<DoubleArray, DoubleArray> {
        val g = DoubleArray(pts.size)
        val l = DoubleArray(pts.size)
        if (pts.none { it.altitude != 0.0 }) return Pair(g, l)
        val t = ElevationTracker(thresholdM = 3.0, alpha = 0.3)
        for (i in pts.indices) {
            t.add(pts[i].altitude)
            g[i] = t.gain
            l[i] = t.loss
        }
        return Pair(g, l)
    }

    private fun nearestIndex(p: GeoPoint, from: Int, to: Int): Int {
        var best = from
        var bestD = Double.MAX_VALUE
        for (i in from..to) {
            val d = GeoMath.distance(p, path[i])
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        return best
    }

    private fun refine(pos: GeoPoint, idx: Int): Hit {
        if (path.size < 2) return Hit(GeoMath.distance(pos, path[0]), 0.0, path[0])
        var best: Hit? = null
        for (i in intArrayOf(idx - 1, idx)) {
            if (i < 0 || i >= path.size - 1) continue
            val pr = GeoMath.project(pos, path[i], path[i + 1])
            val along = cum[i] + pr.t * (cum[i + 1] - cum[i])
            val current = best
            if (current == null || pr.perp < current.perp) best = Hit(pr.perp, along, pr.point)
        }
        return best ?: Hit(GeoMath.distance(pos, path[idx]), cum[idx], path[idx])
    }

    private fun resample(step: Double): List<GeoPoint> {
        val total = cum.last()
        if (path.size < 2 || total < step * 2) return emptyList()
        val out = ArrayList<GeoPoint>()
        var seg = 1
        var d = 0.0
        while (d <= total) {
            while (seg < path.size - 1 && cum[seg] < d) seg++
            val a = path[seg - 1]
            val b = path[seg]
            val segLen = cum[seg] - cum[seg - 1]
            val t = if (segLen > 0.0) ((d - cum[seg - 1]) / segLen).coerceIn(0.0, 1.0) else 0.0
            out.add(
                GeoPoint(
                    a.latitude + (b.latitude - a.latitude) * t,
                    a.longitude + (b.longitude - a.longitude) * t
                )
            )
            d += step
        }
        return out
    }

    /** Deteta curvas comparando o rumo 30 m antes com o rumo 30 m depois de cada ponto. */
    private fun detectManeuvers(): List<Maneuver> {
        val step = RESAMPLE_STEP
        val w = TURN_WINDOW
        val raw = resample(step)
        if (raw.size < 2 * w + 1) return emptyList()
        val rs = smooth(raw)
        val total = cum.last()

        val deltas = DoubleArray(rs.size)
        for (k in w until rs.size - w) {
            val inB = GeoMath.bearing(rs[k - w], rs[k])
            val outB = GeoMath.bearing(rs[k], rs[k + w])
            deltas[k] = GeoMath.angleDiff(outB, inB)
        }
        val result = ArrayList<Maneuver>()
        var k = w
        while (k < rs.size - w) {
            if (abs(deltas[k]) >= TURN_MIN_DEG) {
                var best = k
                var j = k
                while (j < rs.size - w && abs(deltas[j]) >= TURN_MIN_DEG && deltas[j] * deltas[k] > 0) {
                    if (abs(deltas[j]) > abs(deltas[best])) best = j
                    j++
                }
                val dist = best * step
                if (dist > 15.0 && dist < total - 15.0) result.add(Maneuver(dist, deltas[best]))
                k = j
            } else {
                k++
            }
        }
        return mergeClose(result)
    }

    /** Média móvel de 3 pontos: reduz o ruído do GPS antes de medir ângulos. */
    private fun smooth(pts: List<GeoPoint>): List<GeoPoint> {
        if (pts.size < 3) return pts
        val out = ArrayList<GeoPoint>(pts.size)
        out.add(pts.first())
        for (i in 1 until pts.size - 1) {
            out.add(
                GeoPoint(
                    (pts[i - 1].latitude + pts[i].latitude + pts[i + 1].latitude) / 3.0,
                    (pts[i - 1].longitude + pts[i].longitude + pts[i + 1].longitude) / 3.0
                )
            )
        }
        out.add(pts.last())
        return out
    }

    /** Curvas muito próximas: se forem para o mesmo lado somam-se; caso contrário fica a maior. */
    private fun mergeClose(list: List<Maneuver>): List<Maneuver> {
        if (list.size < 2) return list
        val out = ArrayList<Maneuver>()
        var cur = list[0]
        for (i in 1 until list.size) {
            val next = list[i]
            if (next.distance - cur.distance < TURN_MERGE_METERS) {
                cur = if (next.angle * cur.angle > 0)
                    Maneuver((cur.distance + next.distance) / 2.0, cur.angle + next.angle)
                else if (abs(next.angle) > abs(cur.angle)) next else cur
            } else {
                out.add(cur)
                cur = next
            }
        }
        out.add(cur)
        return out
    }
}
