package pt.wikilocal

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.osmdroid.util.GeoPoint
import pt.wikilocal.data.TrackDatabase
import pt.wikilocal.data.TrackEntity
import pt.wikilocal.data.TrackPointEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Foreground Service (tipo "location"): recebe posições do LocationManager nativo
 * (GPS_PROVIDER, 10 s / 5 m), grava percursos na BD, calcula a navegação e fala as indicações
 * (TextToSpeech do Android) — tudo funciona com o ecrã desligado.
 */
class TrackRecordingService : Service() {

    companion object {
        const val ACTION_START_RECORDING = "pt.wikilocal.action.START_RECORDING"
        const val ACTION_STOP_RECORDING = "pt.wikilocal.action.STOP_RECORDING"
        const val ACTION_PAUSE_RECORDING = "pt.wikilocal.action.PAUSE_RECORDING"
        const val ACTION_RESUME_RECORDING = "pt.wikilocal.action.RESUME_RECORDING"
        const val ACTION_START_NAVIGATION = "pt.wikilocal.action.START_NAVIGATION"
        const val ACTION_STOP_NAVIGATION = "pt.wikilocal.action.STOP_NAVIGATION"
        const val ACTION_PAUSE_NAVIGATION = "pt.wikilocal.action.PAUSE_NAVIGATION"
        const val ACTION_RESUME_NAVIGATION = "pt.wikilocal.action.RESUME_NAVIGATION"
        const val ACTION_STOP_ALL = "pt.wikilocal.action.STOP_ALL"

        private const val TAG = "TrackRecordingService"
        private const val CHANNEL_ID = "mysteps_tracking"
        private const val NOTIFICATION_ID = 1001
        // Fora de estrada: 1 fix a cada 3 s (o filtro próprio trata do ruído e dos saltos).
        // Para poupar mais bateria, aumente MIN_TIME_MS (ex.: 5000L).
        private const val MIN_TIME_MS = 3_000L
        private const val MIN_DISTANCE_M = 0f
        private const val SIGNAL_CHECK_MS = 10_000L
        private const val SIGNAL_LOST_MS = 25_000L
        private const val SIGNAL_WARN_REPEAT_MS = 120_000L
    }

    private lateinit var locationManager: LocationManager
    private lateinit var notificationManager: NotificationManager
    private lateinit var guide: NavigationGuide

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var channel: Channel<Location?>? = null
    private var consumer: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private var inForeground = false
    private var listening = false
    private var recording = false
    private var paused = false
    private var navigating = false
    private var navPaused = false
    private var prevFix: Location? = null

    // Qualidade do GPS
    private val filter = LocationFilter()
    private val sampling = SamplingPolicy()
    private var intervalMs = MIN_TIME_MS

    // Elevação acumulada: barómetro (preciso) com a altitude do GPS como alternativa
    private val gpsElev = ElevationTracker(thresholdM = 5.0, alpha = 0.3)
    private val baroElev = ElevationTracker(thresholdM = 2.0, alpha = 0.05)
    private var baroRegistered = false
    private val baroListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            if (!(recording || navigating) || statsPaused()) return
            val alt = SensorManager.getAltitude(SensorManager.PRESSURE_STANDARD_ATMOSPHERE, event.values[0])
            baroElev.add(alt.toDouble())
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        }
    }
    private lateinit var gnssMonitor: GnssMonitor
    private val handler = Handler(Looper.getMainLooper())
    private var lastAcceptedAt = 0L
    private var lastWeakSpeech = 0L
    private var watchdogRunning = false
    private val watchdog = object : Runnable {
        override fun run() {
            checkSignal()
            handler.postDelayed(this, SIGNAL_CHECK_MS)
        }
    }

    // Voz
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeech: String? = null
    private var focusRequest: AudioFocusRequest? = null
    private val audioAttrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            handleRaw(location)
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        }

        override fun onProviderEnabled(provider: String) {
        }

        override fun onProviderDisabled(provider: String) {
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        guide = NavigationGuide(this) { speak(it) }
        gnssMonitor = GnssMonitor(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_RECORDING -> if (prepare()) {
                beginRecording()
                refreshNotification()
            }
            ACTION_START_NAVIGATION -> if (prepare()) {
                if (!navigating) {
                    if (!recording) resetStats()
                    navigating = true
                    navPaused = false
                    TrackerState.navPaused.value = false
                    guide.start()
                    TrackerState.navigating.value = true
                    initTts()
                    lastAcceptedAt = now()
                    val known = TrackerState.lastLocation.value
                    if (known != null && known.ageMs() < 60_000L) guide.onLocation(known)
                }
                refreshNotification()
            }
            ACTION_PAUSE_RECORDING -> pauseRecording()
            ACTION_RESUME_RECORDING -> resumeRecording()
            ACTION_STOP_RECORDING -> {
                endRecording()
                stopIfIdle()
            }
            ACTION_PAUSE_NAVIGATION -> pauseNavigation()
            ACTION_RESUME_NAVIGATION -> resumeNavigation()
            ACTION_STOP_NAVIGATION -> {
                endNavigation()
                stopIfIdle()
            }
            ACTION_STOP_ALL -> {
                endRecording()
                endNavigation()
                stopIfIdle()
            }
            else -> stopIfIdle()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopListening()
        stopWatchdog()
        gnssMonitor.stop()
        stopBarometer()
        releaseWakeLock()
        endRecording()
        endNavigation()
        clockPause()
        TrackerState.recording.value = false
        TrackerState.paused.value = false
        TrackerState.navigating.value = false
        TrackerState.navPaused.value = false
        tts?.stop()
        tts?.shutdown()
        tts = null
        abandonFocus()
        val c = consumer
        if (c == null) scope.cancel() else c.invokeOnCompletion { scope.cancel() }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- posições

    private fun handleRaw(raw: Location) {
        val f = filter.process(raw) ?: return        // fix rejeitado (precisão má ou salto impossível)
        lastAcceptedAt = now()
        TrackerState.lastLocation.value = f

        // Amostragem adaptativa: re-regista o GPS quando o regime de velocidade muda
        val desired = sampling.desiredIntervalMs(f, navigating, now())
        if (desired != intervalMs) {
            intervalMs = desired
            handler.post { restartListening() }
        }

        if (!statsPaused()) {
            val p = prevFix
            // Só conta movimento acima do ruído (evita somar quilómetros parado sob copas/arvoredo)
            val threshold = (f.accuracy * 0.4f).coerceIn(3f, 10f)
            val moved = if (p == null) true else p.distanceTo(f) >= threshold
            if (moved) {
                f.bestAltitude()?.let { gpsElev.add(it) }   // parado não acumula ruído de altitude
                if (p != null) TrackerState.distanceMeters.value += p.distanceTo(f)
                prevFix = f
                if (recording && !paused) channel?.trySend(f)
            }
        }
        publishElevation()
        if (navigating && !navPaused) guide.onLocation(f)
        refreshNotification()
    }

    private fun statsPaused(): Boolean = if (recording) paused else (navigating && navPaused)

    private fun publishElevation() {
        val src = if (baroElev.samples > 0) baroElev else gpsElev
        val cur = TrackerState.elevation.value
        if (kotlin.math.abs(src.gain - cur.gain) > 0.01 || kotlin.math.abs(src.loss - cur.loss) > 0.01) {
            TrackerState.elevation.value = TrackerState.Elevation(src.gain, src.loss)
        }
    }

    private fun startBarometer() {
        if (baroRegistered) return
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_PRESSURE) ?: return
        baroRegistered = sm.registerListener(baroListener, sensor, SensorManager.SENSOR_DELAY_NORMAL)
    }

    private fun stopBarometer() {
        if (!baroRegistered) return
        (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(baroListener)
        baroRegistered = false
    }

    private fun checkSignal() {
        val active = recording || navigating
        if (!active) return
        val t = now()
        if (navigating && !navPaused && t - lastAcceptedAt > SIGNAL_LOST_MS &&
            t - lastWeakSpeech > SIGNAL_WARN_REPEAT_MS
        ) {
            lastWeakSpeech = t
            speak(getString(R.string.gps_weak))
        }
    }

    private fun startWatchdog() {
        if (watchdogRunning) return
        watchdogRunning = true
        lastAcceptedAt = now()
        handler.postDelayed(watchdog, SIGNAL_CHECK_MS)
    }

    private fun stopWatchdog() {
        watchdogRunning = false
        handler.removeCallbacks(watchdog)
    }

    // ---------------------------------------------------------------- arranque / paragem

    private fun prepare(): Boolean {
        try {
            enterForeground()
        } catch (e: Exception) {
            Log.e(TAG, "Não foi possível iniciar o foreground service", e)
            stopSelf()
            return false
        }
        if (!listening) {
            filter.reset()
            sampling.reset()
            intervalMs = MIN_TIME_MS
        }
        acquireWakeLock()
        gnssMonitor.start()
        startBarometer()
        startWatchdog()
        if (!startListening()) {
            stopIfIdle()
            return false
        }
        return true
    }

    private fun enterForeground() {
        if (inForeground) return
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), type)
        inForeground = true
    }

    @SuppressLint("MissingPermission")
    private fun startListening(): Boolean {
        if (listening) return true
        val granted = ContextCompat.checkSelfPermission(
            this, android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) return false
        return try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                intervalMs,
                MIN_DISTANCE_M,
                locationListener,
                Looper.getMainLooper()
            )
            listening = true
            // Posição recente conhecida: dá indicações mais cedo enquanto o GPS não fixa
            val last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (last != null && System.currentTimeMillis() - last.time < 120_000L) {
                if (TrackerState.lastLocation.value == null) TrackerState.lastLocation.value = last
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "requestLocationUpdates falhou", e)
            false
        }
    }

    private fun restartListening() {
        if (!listening) return
        stopListening()
        startListening()
    }

    private fun stopListening() {
        if (!listening) return
        try {
            locationManager.removeUpdates(locationListener)
        } catch (e: Exception) {
            Log.w(TAG, "removeUpdates falhou", e)
        }
        listening = false
    }

    private fun stopIfIdle() {
        if (recording || navigating) {
            refreshNotification()
            return
        }
        clockPause()
        stopListening()
        stopWatchdog()
        gnssMonitor.stop()
        stopBarometer()
        releaseWakeLock()
        if (inForeground) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            inForeground = false
        }
        stopSelf()
    }

    private fun endNavigation() {
        if (!navigating) return
        navigating = false
        navPaused = false
        TrackerState.navigating.value = false
        TrackerState.navPaused.value = false
        guide.stop()
        tts?.stop()
    }

    private fun pauseNavigation() {
        if (!navigating || navPaused) return
        navPaused = true
        TrackerState.navPaused.value = true
        prevFix = null
        if (!recording) clockPause()
        tts?.stop()
        refreshNotification()
    }

    private fun resumeNavigation() {
        if (!navigating || !navPaused) return
        navPaused = false
        TrackerState.navPaused.value = false
        prevFix = null
        if (!recording) clockResume()
        guide.onResumed()
        val known = TrackerState.lastLocation.value
        if (known != null && known.ageMs() < 60_000L) guide.onLocation(known)
        refreshNotification()
    }

    // ---------------------------------------------------------------- estatísticas (HUD)

    private fun now() = SystemClock.elapsedRealtime()

    private fun resetStats() {
        TrackerState.distanceMeters.value = 0.0
        prevFix = null
        gpsElev.reset()
        baroElev.reset()
        TrackerState.elevation.value = TrackerState.Elevation()
        paused = false
        TrackerState.paused.value = false
        TrackerState.clock.value = TrackerState.Clock(0L, now(), true)
    }

    private fun clockPause() {
        val c = TrackerState.clock.value
        if (c.running) TrackerState.clock.value = TrackerState.Clock(c.accumulatedMs + now() - c.segmentStart, 0L, false)
    }

    private fun clockResume() {
        val c = TrackerState.clock.value
        if (!c.running) TrackerState.clock.value = TrackerState.Clock(c.accumulatedMs, now(), true)
    }

    // ---------------------------------------------------------------- gravação

    private fun beginRecording() {
        if (recording) return
        recording = true
        resetStats()
        TrackerState.recordedPoints.value = emptyList()
        TrackerState.recording.value = true

        val ch = Channel<Location?>(Channel.UNLIMITED)
        channel = ch
        consumer = scope.launch {
            val dao = TrackDatabase.get(applicationContext).trackDao()
            val startTime = System.currentTimeMillis()
            val trackId = dao.insertTrack(
                TrackEntity(name = defaultTrackName(startTime), startTime = startTime)
            )
            var distance = 0.0
            var count = 0
            var previous: Location? = null
            try {
                for (item in ch) {
                    if (item == null) {          // marcador de pausa: não somar o salto entre pontos
                        previous = null
                        continue
                    }
                    val loc = item
                    previous?.let { distance += it.distanceTo(loc) }
                    previous = loc
                    count++
                    val alt = loc.bestAltitude()
                    dao.insertPoint(
                        TrackPointEntity(
                            trackId = trackId,
                            latitude = loc.latitude,
                            longitude = loc.longitude,
                            altitude = alt,
                            time = loc.time
                        )
                    )
                    val gp = GeoPoint(loc.latitude, loc.longitude, alt ?: 0.0)
                    TrackerState.recordedPoints.update { it + gp }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Erro a gravar ponto", e)
            }
            if (count == 0) dao.deleteTrack(trackId)
            else {
                val elev = TrackerState.elevation.value
                dao.finishTrack(trackId, System.currentTimeMillis(), distance, elev.gain, elev.loss)
            }
        }
    }

    private fun pauseRecording() {
        if (!recording || paused) return
        paused = true
        TrackerState.paused.value = true
        channel?.trySend(null)
        prevFix = null
        filter.reset()
        clockPause()
        refreshNotification()
    }

    private fun resumeRecording() {
        if (!recording || !paused) return
        paused = false
        TrackerState.paused.value = false
        prevFix = null
        clockResume()
        refreshNotification()
    }

    private fun endRecording() {
        if (!recording) return
        recording = false
        paused = false
        TrackerState.recording.value = false
        TrackerState.paused.value = false
        channel?.close()
        channel = null
        if (!navigating) clockPause()
    }

    private fun defaultTrackName(time: Long): String =
        getString(
            R.string.track_default_name,
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(time))
        )

    // ---------------------------------------------------------------- voz

    private fun initTts() {
        if (tts != null) return
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.let { t ->
                    var r = t.setLanguage(Locale("pt", "PT"))
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                        r = t.setLanguage(Locale.getDefault())
                    }
                    t.setAudioAttributes(audioAttrs)
                    t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                        }

                        override fun onDone(utteranceId: String?) {
                            abandonFocus()
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            abandonFocus()
                        }
                    })
                    ttsReady = true
                    pendingSpeech?.let { p ->
                        pendingSpeech = null
                        speak(p)
                    }
                }
            } else {
                Log.w(TAG, "TextToSpeech indisponível (status=$status)")
            }
        }
    }

    private fun speak(text: String) {
        if (!TrackerState.voiceEnabled.value) return
        initTts()
        if (!ttsReady) {
            pendingSpeech = text
            return
        }
        requestFocus()
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "mysteps-" + System.nanoTime())
    }

    @Suppress("DEPRECATION")
    private fun requestFocus() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(audioAttrs)
                .build()
            focusRequest = req
            am.requestAudioFocus(req)
        } else {
            am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        }
    }

    @Suppress("DEPRECATION")
    private fun abandonFocus() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest?.let { am.abandonAudioFocusRequest(it) }
        } else {
            am.abandonAudioFocus(null)
        }
    }

    // ---------------------------------------------------------------- notificação

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val ch = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notif_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.notif_channel_desc)
            setShowBadge(false)
        }
        notificationManager.createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        fun action(code: Int, act: String) = PendingIntent.getService(
            this, code,
            Intent(this, TrackRecordingService::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val km = TrackerState.distanceMeters.value / 1000.0
        val guidance = TrackerState.guidance.value
        val text = when {
            navigating && navPaused -> getString(R.string.notif_nav_paused)
            navigating && guidance != null -> guidance.text
            recording && paused -> getString(R.string.notif_paused, km)
            recording -> getString(R.string.notif_recording, km)
            else -> getString(R.string.notif_navigating)
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (recording) {
            if (paused) builder.addAction(0, getString(R.string.btn_resume), action(2, ACTION_RESUME_RECORDING))
            else builder.addAction(0, getString(R.string.btn_pause), action(2, ACTION_PAUSE_RECORDING))
        } else if (navigating) {
            if (navPaused) builder.addAction(0, getString(R.string.btn_nav_resume), action(3, ACTION_RESUME_NAVIGATION))
            else builder.addAction(0, getString(R.string.btn_nav_pause), action(3, ACTION_PAUSE_NAVIGATION))
        }
        builder.addAction(0, getString(R.string.stop), action(1, ACTION_STOP_ALL))
        return builder.build()
    }

    private fun refreshNotification() {
        if (inForeground) notificationManager.notify(NOTIFICATION_ID, buildNotification())
    }

    // ---------------------------------------------------------------- wake lock

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mysteps:tracking").apply {
            setReferenceCounted(false)
            acquire(12 * 60 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }
}
