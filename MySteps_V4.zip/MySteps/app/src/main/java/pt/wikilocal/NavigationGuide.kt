package pt.wikilocal

import android.content.Context
import android.location.Location
import android.os.SystemClock
import kotlinx.coroutines.flow.update
import org.osmdroid.util.GeoPoint
import kotlin.math.abs

/**
 * Indicações de navegação (visuais e de voz) tipo Waze/Google Maps ao longo de um percurso GPX/gravado.
 * Corre no serviço (thread principal), por isso a voz funciona com o ecrã desligado.
 *
 * Fases:
 *  1. APROXIMAÇÃO: ainda não está no percurso -> direção e distância até ao percurso (se perto)
 *     ou até ao ponto de partida (se longe).
 *  2. NO PERCURSO: assim que está a ≤ 40 m do percurso, continua a partir da posição atual,
 *     com avisos de curvas, distância restante e saída do percurso.
 */
class NavigationGuide(
    private val context: Context,
    private val speak: (String) -> Unit
) {
    private companion object {
        val MANEUVER_THRESHOLDS = intArrayOf(120, 40, 15)
        val APPROACH_THRESHOLDS = intArrayOf(500, 200, 100, 50)
        const val OFF_ROUTE_REPEAT_MS = 45_000L
    }

    private var joined = false
    private var offCount = 0
    private var wasOff = false
    private var arrivedSpoken = false
    private var lastKm = -1
    private var lastOffSpeech = 0L
    private var approachSpoken = -1
    private var seenVersion = 0
    private val spokenLevel = HashMap<Int, Int>()

    fun start() {
        joined = false
        offCount = 0
        wasOff = false
        arrivedSpoken = false
        lastKm = -1
        lastOffSpeech = 0L
        approachSpoken = -1
        spokenLevel.clear()
        seenVersion = TrackerState.routeVersion.value
        TrackerState.engine.resetProgress()
        TrackerState.navStatus.value = null
        TrackerState.guidance.value = null
    }

    /** Chamado quando o utilizador retoma a navegação depois de uma pausa. */
    fun onResumed() {
        offCount = 0
        speak(s(R.string.guide_resumed))
    }

    fun stop() {
        TrackerState.navStatus.value = null
        TrackerState.guidance.value = null
    }

    fun onLocation(loc: Location) {
        val engine = TrackerState.engine
        if (!engine.isLoaded) return
        syncVersion()
        val pos = GeoPoint(loc.latitude, loc.longitude)
        val acc = if (loc.hasAccuracy()) loc.accuracy.toDouble() else 15.0
        if (!joined) {
            approach(loc, pos, acc)
            return
        }

        val st = engine.update(pos, acc)
        TrackerState.navStatus.value = st

        if (st.arrived) {
            if (!arrivedSpoken) {
                arrivedSpoken = true
                speak(s(R.string.guide_arrived))
            }
            TrackerState.guidance.value = TrackerState.Guidance("✔", s(R.string.guide_arrived), null)
            return
        }

        if (st.offRoute) {
            offCount++
            if (offCount < 2) return        // confirma com 2 fixes seguidos (evita falsos alarmes do GPS)
            val target = st.nearestPoint ?: engine.startPoint ?: return
            val dist = GeoMath.distance(pos, target)
            val brg = GeoMath.bearing(pos, target)
            val text = s(R.string.guide_off_route, fmtDist(dist), cardinal(brg))
            val now = SystemClock.elapsedRealtime()
            if (!wasOff || now - lastOffSpeech > OFF_ROUTE_REPEAT_MS) {
                speak(text)
                lastOffSpeech = now
            }
            wasOff = true
            TrackerState.guidance.value = TrackerState.Guidance(headingArrow(loc, brg), text, brg)
            return
        }
        offCount = 0
        if (wasOff) {
            wasOff = false
            speak(s(R.string.guide_back_on_route))
        }

        val m = engine.nextManeuver(st.distanceAlong)
        val ahead = engine.pointAhead(st.distanceAlong, 30.0)
        val targetBearing = ahead?.let { GeoMath.bearing(pos, it) }
        var maneuverDistance = Double.MAX_VALUE

        if (m == null) {
            TrackerState.guidance.value = TrackerState.Guidance(
                "↑", s(R.string.guide_straight, fmtDist(st.remaining)), targetBearing
            )
        } else {
            val d = m.distance - st.distanceAlong
            maneuverDistance = d
            val mt = maneuverText(m)
            val text = if (d <= 15) s(R.string.guide_now, mt) else s(R.string.guide_in, fmtDist(d), mt)
            val arrow = if (d <= 120) arrowFor(m) else "↑"
            TrackerState.guidance.value = TrackerState.Guidance(arrow, text, targetBearing)

            val level = MANEUVER_THRESHOLDS.count { d <= it }
            val key = m.distance.toInt()
            if (level > (spokenLevel[key] ?: 0)) {
                spokenLevel[key] = level
                speak(text)
            }
        }

        // Aviso de quilómetros restantes (se não houver curva iminente)
        val km = (st.remaining / 1000.0).toInt()
        if (lastKm == -1) {
            lastKm = km
        } else if (km < lastKm) {
            lastKm = km
            if (km >= 1 && engine.totalMeters > 2000 && maneuverDistance > 200) {
                speak(if (km == 1) s(R.string.guide_km_left_one) else s(R.string.guide_km_left, km))
            }
        }
    }

    // ------------------------------------------------------------------ aproximação

    private fun approach(loc: Location, pos: GeoPoint, acc: Double) {
        val engine = TrackerState.engine
        val hit = engine.nearestOnRoute(pos) ?: return

        if (hit.distance <= RouteEngine.routeTolerance(acc)) {
            // Já estamos no percurso: continua a partir da posição atual
            joined = true
            engine.setStartNearest(pos)
            TrackerState.routeVersion.update { it + 1 }
            seenVersion = TrackerState.routeVersion.value
            spokenLevel.clear()
            lastKm = -1
            speak(s(R.string.guide_start_on_route))
            onLocation(loc)
            return
        }

        val near = hit.distance <= RouteEngine.NEAR_METERS
        val target = if (near) hit.point else (engine.startPoint ?: hit.point)
        val dist = GeoMath.distance(pos, target)
        val brg = GeoMath.bearing(pos, target)
        val text = s(
            if (near) R.string.guide_go_to_route else R.string.guide_go_to_start,
            fmtDist(dist), cardinal(brg)
        )
        TrackerState.guidance.value = TrackerState.Guidance(headingArrow(loc, brg), text, brg)

        val level = APPROACH_THRESHOLDS.count { dist <= it }
        if (approachSpoken == -1 || level > approachSpoken) {
            approachSpoken = level
            speak(text)
        }
    }

    // ------------------------------------------------------------------ auxiliares

    private fun syncVersion() {
        val v = TrackerState.routeVersion.value
        if (v != seenVersion) {
            seenVersion = v
            spokenLevel.clear()
            lastKm = -1
            arrivedSpoken = false
            wasOff = false
        }
    }

    private fun s(id: Int, vararg args: Any): String = context.getString(id, *args)

    private fun fmtDist(m: Double): String =
        if (m >= 1000.0) s(R.string.dist_km, m / 1000.0)
        else s(R.string.dist_m, (Math.round(m / 10.0) * 10).toInt().coerceAtLeast(10))

    private fun cardinal(bearing: Double): String {
        val names = context.resources.getStringArray(R.array.cardinals)
        return names[((bearing + 22.5) / 45.0).toInt() % 8]
    }

    private fun maneuverText(m: RouteEngine.Maneuver): String {
        val a = abs(m.angle)
        val right = m.angle > 0
        return when {
            a >= 165 -> s(R.string.turn_uturn)
            a >= 125 -> s(if (right) R.string.turn_sharp_right else R.string.turn_sharp_left)
            a >= 65 -> s(if (right) R.string.turn_right else R.string.turn_left)
            else -> s(if (right) R.string.turn_slight_right else R.string.turn_slight_left)
        }
    }

    private fun arrowFor(m: RouteEngine.Maneuver): String {
        val a = abs(m.angle)
        val right = m.angle > 0
        return when {
            a >= 165 -> "↩"
            a >= 125 -> if (right) "↘" else "↙"
            a >= 65 -> if (right) "→" else "←"
            else -> if (right) "↗" else "↖"
        }
    }

    /** Seta relativa ao sentido de marcha (se conhecido); caso contrário um alvo "◎" (a bússola indica o rumo). */
    private fun headingArrow(loc: Location, bearingToTarget: Double): String {
        if (!(loc.hasBearing() && loc.hasSpeed() && loc.speed > 0.7f)) return "◎"
        val rel = GeoMath.angleDiff(bearingToTarget, loc.bearing.toDouble())
        val a = abs(rel)
        val right = rel > 0
        return when {
            a < 22.5 -> "↑"
            a < 67.5 -> if (right) "↗" else "↖"
            a < 112.5 -> if (right) "→" else "←"
            a < 157.5 -> if (right) "↘" else "↙"
            else -> "↓"
        }
    }
}
