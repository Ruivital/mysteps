package pt.wikilocal

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import androidx.core.content.ContextCompat
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.MapTileProviderArray
import org.osmdroid.tileprovider.MapTileProviderBasic
import org.osmdroid.tileprovider.modules.IArchiveFile
import org.osmdroid.tileprovider.modules.MBTilesFileArchive
import org.osmdroid.tileprovider.modules.MapTileFileArchiveProvider
import org.osmdroid.tileprovider.modules.MapTileModuleProviderBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.tileprovider.util.SimpleRegisterReceiver
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.io.File

/**
 * Gere o MapView do OSMDroid em modo 100% offline.
 * Os mapas são ficheiros MBTiles lidos por MBTilesFileArchive através de um MapTileProviderArray.
 */
class MapManager(private val context: Context, private val mapView: MapView) {

    data class MbtilesInfo(val minZoom: Int, val maxZoom: Int, val bounds: BoundingBox?)

    companion object {
        /** Abre o MBTiles em modo leitura e valida-o. Lança IllegalArgumentException se for inválido. */
        fun readInfo(file: File): MbtilesInfo {
            val db = try {
                SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
            } catch (e: SQLiteException) {
                throw IllegalArgumentException("não é uma base de dados SQLite válida")
            }
            db.use {
                try {
                    it.rawQuery("SELECT name FROM sqlite_master WHERE name = 'tiles'", null).use { c ->
                        require(c.moveToFirst()) { "o ficheiro não contém a tabela 'tiles' (não é MBTiles)" }
                    }
                    val meta = HashMap<String, String>()
                    try {
                        it.rawQuery("SELECT name, value FROM metadata", null).use { c ->
                            while (c.moveToNext()) {
                                val k = c.getString(0)
                                val v = c.getString(1)
                                if (k != null && v != null) meta[k] = v
                            }
                        }
                    } catch (_: SQLiteException) {
                        // metadata é opcional
                    }
                    var minZ = meta["minzoom"]?.trim()?.toIntOrNull()
                    var maxZ = meta["maxzoom"]?.trim()?.toIntOrNull()
                    if (minZ == null || maxZ == null) {
                        it.rawQuery("SELECT MIN(zoom_level), MAX(zoom_level) FROM tiles", null).use { c ->
                            if (c.moveToFirst() && !c.isNull(0)) {
                                minZ = c.getInt(0)
                                maxZ = c.getInt(1)
                            }
                        }
                    }
                    val lo = (minZ ?: 0).coerceIn(0, 22)
                    val hi = (maxZ ?: 18).coerceIn(lo, 22)

                    val b = meta["bounds"]?.split(",")?.mapNotNull { s -> s.trim().toDoubleOrNull() }
                    val bounds = if (b != null && b.size == 4 &&
                        b[1] in -85.0..85.0 && b[3] in -85.0..85.0 && b[3] > b[1] && b[2] > b[0]
                    ) BoundingBox(b[3], b[2], b[1], b[0]) else null
                    return MbtilesInfo(lo, hi, bounds)
                } catch (e: SQLiteException) {
                    throw IllegalArgumentException("ficheiro MBTiles corrompido (${e.message})")
                }
            }
        }
    }

    enum class OnlineSource { OSM, TOPO }

    private val topoSource = XYTileSource(
        "OpenTopoMap", 0, 17, 256, ".png",
        arrayOf(
            "https://a.tile.opentopomap.org/",
            "https://b.tile.opentopomap.org/",
            "https://c.tile.opentopomap.org/"
        ),
        "© OpenStreetMap · SRTM · OpenTopoMap (CC-BY-SA)"
    )

    var hasOfflineMap = false
        private set
    var onLongPress: ((GeoPoint) -> Unit)? = null

    private var dark = false

    /** Escurece os tiles: inverte as cores e roda o tom 180° (água continua azul, mata verde, tudo escuro). */
    private val darkFilter: ColorMatrixColorFilter by lazy {
        val invert = ColorMatrix(
            floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        val hue = ColorMatrix(
            floatArrayOf(
                -0.574f, 1.430f, 0.144f, 0f, 0f,
                0.426f, 0.430f, 0.144f, 0f, 0f,
                0.426f, 1.430f, -0.856f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        val dim = ColorMatrix().apply { setScale(0.85f, 0.85f, 0.85f, 1f) }
        invert.postConcat(hue)
        invert.postConcat(dim)
        ColorMatrixColorFilter(invert)
    }

    private val density = context.resources.displayMetrics.density
    private val fullLine = newLine(0x99777777.toInt(), 4f)
    private val activeLine = newLine(0xFF1565C0.toInt(), 5f)
    private val recordedLine = newLine(0xFFD32F2F.toInt(), 5f)
    private val startMarker = Marker(mapView).apply {
        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        infoWindow = null
        isEnabled = false
    }
    private val meMarker = Marker(mapView).apply {
        icon = ContextCompat.getDrawable(context, R.drawable.ic_my_position)
        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        infoWindow = null
        isEnabled = false
    }

    fun init() {
        mapView.setMultiTouchControls(true)
        mapView.setUseDataConnection(false)           // nunca usar a rede
        mapView.isTilesScaledToDpi = true
        mapView.controller.setZoom(6.0)
        mapView.controller.setCenter(GeoPoint(39.6, -8.0))

        val receiver = object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint?): Boolean = false
            override fun longPressHelper(p: GeoPoint?): Boolean {
                if (p == null) return false
                onLongPress?.invoke(p)
                return true
            }
        }
        // Ordem de desenho (de baixo para cima)
        mapView.overlays.add(MapEventsOverlay(receiver))
        mapView.overlays.add(fullLine)
        mapView.overlays.add(activeLine)
        mapView.overlays.add(recordedLine)
        mapView.overlays.add(startMarker)
        mapView.overlays.add(meMarker)
    }

    // ------------------------------------------------------------------ mapa offline

    /** Carrega um ficheiro MBTiles (local, em armazenamento privado da app). */
    fun loadMbtiles(file: File): MbtilesInfo {
        val info = readInfo(file)
        val archive = MBTilesFileArchive.getDatabaseFileArchive(file)
        val registerReceiver = SimpleRegisterReceiver(context.applicationContext)
        val tileSource = XYTileSource(
            "mbtiles-" + file.name, info.minZoom, info.maxZoom, 256, ".png", arrayOf("")
        )
        val archiveProvider = MapTileFileArchiveProvider(
            registerReceiver, tileSource, arrayOf<IArchiveFile>(archive)
        )
        val provider = MapTileProviderArray(
            tileSource, registerReceiver, arrayOf<MapTileModuleProviderBase>(archiveProvider)
        )
        mapView.setTileProvider(provider)
        mapView.setUseDataConnection(false)
        mapView.setMinZoomLevel(info.minZoom.toDouble())
        mapView.setMaxZoomLevel(info.maxZoom.toDouble())
        hasOfflineMap = true
        applyTilesFilter()
        return info
    }

    /**
     * Mapa online (OpenStreetMap ou OpenTopoMap). Os tiles vistos ficam em cache no telemóvel,
     * por isso as zonas já visitadas continuam a aparecer sem rede.
     */
    fun useOnline(source: OnlineSource) {
        mapView.setTileProvider(MapTileProviderBasic(context.applicationContext))
        mapView.setTileSource(if (source == OnlineSource.OSM) TileSourceFactory.MAPNIK else topoSource)
        mapView.setUseDataConnection(true)
        mapView.setMinZoomLevel(null)
        mapView.setMaxZoomLevel(null)
        hasOfflineMap = false
        applyTilesFilter()
    }

    /** Liberta o MBTiles atual (fecha a base de dados) e volta ao fornecedor vazio. */
    fun clearOfflineMap() {
        mapView.setTileProvider(MapTileProviderBasic(context.applicationContext))
        mapView.setUseDataConnection(false)
        mapView.setMinZoomLevel(null)
        mapView.setMaxZoomLevel(null)
        hasOfflineMap = false
        applyTilesFilter()
    }

    // ------------------------------------------------------------------ tema do mapa

    fun setDarkMode(enabled: Boolean) {
        if (enabled == dark) return
        dark = enabled
        applyTilesFilter()
        activeLine.outlinePaint.color = if (dark) 0xFF64B5F6.toInt() else 0xFF1565C0.toInt()
        recordedLine.outlinePaint.color = if (dark) 0xFFFF5252.toInt() else 0xFFD32F2F.toInt()
        mapView.invalidate()
    }

    /** Tem de ser chamado sempre que o fornecedor de tiles muda (o overlay é recriado). */
    private fun applyTilesFilter() {
        val overlay = mapView.overlayManager.tilesOverlay
        if (dark) {
            overlay.setColorFilter(darkFilter)
            overlay.setLoadingBackgroundColor(0xFF121212.toInt())
            overlay.setLoadingLineColor(0xFF2A2A2A.toInt())
        } else {
            overlay.setColorFilter(null)
            overlay.setLoadingBackgroundColor(0xFFCCCCCC.toInt())
            overlay.setLoadingLineColor(0xFFC8C8C8.toInt())
        }
        mapView.invalidate()
    }

    // ------------------------------------------------------------------ overlays

    fun showRoute(full: List<GeoPoint>, active: List<GeoPoint>) {
        // Só para desenhar: ficheiros grandes são simplificados (a navegação usa o percurso completo)
        val fullDraw = PathSimplifier.simplifyForDisplay(full)
        val activeDraw = PathSimplifier.simplifyForDisplay(active)
        fullLine.setPoints(fullDraw)
        fullLine.isEnabled = fullDraw.size >= 2
        activeLine.setPoints(activeDraw)
        activeLine.isEnabled = activeDraw.size >= 2
        mapView.invalidate()
    }

    fun showRecordedTrack(points: List<GeoPoint>) {
        recordedLine.setPoints(points)
        recordedLine.isEnabled = points.size >= 2
        mapView.invalidate()
    }

    fun showStartMarker(p: GeoPoint?) {
        if (p == null) {
            startMarker.isEnabled = false
        } else {
            startMarker.position = p
            startMarker.isEnabled = true
        }
        mapView.invalidate()
    }

    fun updateMyPosition(p: GeoPoint?) {
        if (p == null) {
            meMarker.isEnabled = false
        } else {
            meMarker.position = p
            meMarker.isEnabled = true
        }
        mapView.invalidate()
    }

    // ------------------------------------------------------------------ câmara

    fun centerOn(p: GeoPoint) {
        if (mapView.zoomLevelDouble < 15.0) mapView.controller.setZoom(16.0)
        mapView.controller.setCenter(p)
    }

    /** Segue a posição sem alterar o zoom. */
    fun follow(p: GeoPoint) {
        mapView.controller.animateTo(p)
    }

    fun zoomTo(points: List<GeoPoint>) {
        if (points.size < 2) return
        mapView.post { mapView.zoomToBoundingBox(BoundingBox.fromGeoPoints(points), true, (48 * density).toInt()) }
    }

    fun zoomToBox(box: BoundingBox) {
        mapView.post { mapView.zoomToBoundingBox(box, false, 0) }
    }

    // ------------------------------------------------------------------ ciclo de vida

    fun onResume() = mapView.onResume()
    fun onPause() = mapView.onPause()
    fun onDestroy() = mapView.onDetach()

    private fun newLine(color: Int, widthDp: Float): Polyline = Polyline().apply {
        outlinePaint.color = color
        outlinePaint.strokeWidth = widthDp * context.resources.displayMetrics.density
        outlinePaint.strokeCap = Paint.Cap.ROUND
        isEnabled = false
    }
}
