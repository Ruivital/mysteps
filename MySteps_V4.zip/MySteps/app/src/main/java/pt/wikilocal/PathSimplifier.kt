package pt.wikilocal

import org.osmdroid.util.GeoPoint
import kotlin.math.cos
import kotlin.math.sqrt

/**
 * Douglas–Peucker iterativo (sem recursão, sem alocações por ponto).
 * Serve só para DESENHAR: o motor de navegação continua a usar o percurso completo.
 */
object PathSimplifier {

    fun simplify(points: List<GeoPoint>, toleranceMeters: Double): List<GeoPoint> {
        val n = points.size
        if (n < 3) return points
        val keep = BooleanArray(n)
        keep[0] = true
        keep[n - 1] = true

        val stack = ArrayList<IntArray>()
        stack.add(intArrayOf(0, n - 1))
        while (stack.isNotEmpty()) {
            val range = stack.removeAt(stack.lastIndex)
            val a = range[0]
            val b = range[1]
            if (b - a < 2) continue

            val pa = points[a]
            val pb = points[b]
            val kx = 111320.0 * cos(Math.toRadians(pa.latitude))
            val ky = 110540.0
            val abx = (pb.longitude - pa.longitude) * kx
            val aby = (pb.latitude - pa.latitude) * ky
            val len2 = abx * abx + aby * aby

            var maxD = 0.0
            var idx = -1
            for (i in a + 1 until b) {
                val apx = (points[i].longitude - pa.longitude) * kx
                val apy = (points[i].latitude - pa.latitude) * ky
                val t = if (len2 > 0.0) ((apx * abx + apy * aby) / len2).coerceIn(0.0, 1.0) else 0.0
                val dx = apx - t * abx
                val dy = apy - t * aby
                val d = sqrt(dx * dx + dy * dy)
                if (d > maxD) {
                    maxD = d
                    idx = i
                }
            }
            if (idx != -1 && maxD > toleranceMeters) {
                keep[idx] = true
                stack.add(intArrayOf(a, idx))
                stack.add(intArrayOf(idx, b))
            }
        }
        val out = ArrayList<GeoPoint>()
        for (i in 0 until n) if (keep[i]) out.add(points[i])
        return out
    }

    /** Devolve no máximo ~[maxPoints] pontos, aumentando a tolerância até caber (2 m, 4 m, 8 m, ...). */
    fun simplifyForDisplay(points: List<GeoPoint>, maxPoints: Int = 2500): List<GeoPoint> {
        if (points.size <= maxPoints) return points
        var tol = 2.0
        var out = points
        repeat(12) {
            out = simplify(points, tol)
            if (out.size <= maxPoints) return out
            tol *= 2.0
        }
        return out
    }
}
