package pt.wikilocal

import android.location.Location

/**
 * Amostragem adaptativa: o intervalo do GPS depende da velocidade.
 *  parado   (< 0,5 m/s)  -> 10 s  (poupa bateria, não há curva para desenhar)
 *  a pé     (< 2,5 m/s)  ->  3 s
 *  corrida/bicicleta (< 7 m/s) -> 2 s
 *  veículo  (>= 7 m/s)   ->  1 s  (a 25 m/s, 1 s = 25 m entre pontos)
 * Com histerese: só muda depois de o novo regime se manter (20 s a abrandar, 5 s a acelerar).
 */
class SamplingPolicy {

    companion object {
        const val STATIONARY_MS = 10_000L
        const val WALK_MS = 3_000L
        const val FAST_MS = 2_000L
        const val VEHICLE_MS = 1_000L
        const val SLOW_DOWN_HOLD_MS = 20_000L
        const val SPEED_UP_HOLD_MS = 5_000L
        const val NAVIGATION_MAX_MS = 3_000L     // as indicações de voz precisam de fixes frequentes
    }

    private var current = WALK_MS
    private var candidate = WALK_MS
    private var candidateSince = 0L

    fun reset() {
        current = WALK_MS
        candidate = WALK_MS
        candidateSince = 0L
    }

    fun desiredIntervalMs(loc: Location, navigating: Boolean, nowMs: Long): Long {
        val speed = if (loc.hasSpeed()) loc.speed else 1.0f      // desconhecida: assume a pé
        val target = when {
            speed < 0.5f -> STATIONARY_MS
            speed < 2.5f -> WALK_MS
            speed < 7.0f -> FAST_MS
            else -> VEHICLE_MS
        }
        if (target != candidate) {
            candidate = target
            candidateSince = nowMs
        }
        if (candidate != current) {
            val hold = if (candidate < current) SPEED_UP_HOLD_MS else SLOW_DOWN_HOLD_MS
            if (nowMs - candidateSince >= hold) current = candidate
        }
        return if (navigating) minOf(current, NAVIGATION_MAX_MS) else current
    }
}
