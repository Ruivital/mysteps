package pt.wikilocal.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [TrackEntity::class, TrackPointEntity::class],
    version = 2,
    exportSchema = false
)
abstract class TrackDatabase : RoomDatabase() {

    abstract fun trackDao(): TrackDao

    companion object {
        /** v1 -> v2: subida e descida acumuladas por gravação (as gravações antigas ficam com 0). */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE tracks ADD COLUMN elevationGain REAL NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE tracks ADD COLUMN elevationLoss REAL NOT NULL DEFAULT 0")
            }
        }

        @Volatile
        private var instance: TrackDatabase? = null

        fun get(context: Context): TrackDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    TrackDatabase::class.java,
                    "tracks.db"
                ).addMigrations(MIGRATION_1_2).build().also { instance = it }
            }
    }
}
