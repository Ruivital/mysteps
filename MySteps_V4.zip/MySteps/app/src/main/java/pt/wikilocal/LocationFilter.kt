package pt.wikilocal

import android.location.Location
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Filtro de qualidade do GPS para uso fora de estrada (mata, floresta, montanha, praia):
 *  1. rejeita posições com precisão má (> 40 m);
 *  2. rejeita "saltos" impossíveis (reflexos em encostas/copas); aceita após 3 seguidos (salto real);
 *  3. suaviza o ruído com um filtro de Kalman ponderado pela precisão de cada fix.
 */
class LocationFilter {

    companion object {
        const val MAX_ACCURACY_M = 40f
        const val MAX_SPEED_MS = 12.0          // 43 km/h — acima disto, num fix isolado, é ruído
        const val Q_METRES_PER_SECOND = 3f     // incerteza de movimento a pé / de bicicleta
        const val MAX_CONSECUTIVE_REJECTS = 3
        const val GAP_RESET_S = 30.0
    }

    private var lat = 0.0
    private var lon = 0.0
    private var variance = -1f
    private var lastTimeMs = 0L
    private var lastRaw: Location? = null
    private var rejects = 0

    fun reset() {
        variance = -1f
        lastRaw = null
        rejects = 0
    }

    /** Devolve a posição filtrada, ou null se o fix foi rejeitado. */
    fun process(raw: Location): Location? {
        val acc = if (raw.hasAccuracy()) raw.accuracy else 25f
        if (acc > MAX_ACCURACY_M) return null

        val tMs = raw.elapsedRealtimeNanos / 1_000_000L
        val last = lastRaw
        if (last != null) {
            val dt = (tMs - last.elapsedRealtimeNanos / 1_000_000L) / 1000.0
            if (dt > GAP_RESET_S) {
                variance = -1f
                rejects = 0
            } else if (dt > 0.0) {
                val d = last.distanceTo(raw)
                val lastAcc = if (last.hasAccuracy()) last.accuracy else 25f
                if (d / dt > MAX_SPEED_MS && d > acc + lastAcc) {
                    rejects++
                    if (rejects < MAX_CONSECUTIVE_REJECTS) return null
                    variance = -1f      // salto confirmado: recomeça o filtro
                }
            }
        }
        rejects = 0
        lastRaw = raw

        val a = max(acc, 3f)
        if (variance < 0f) {
            lat = raw.latitude
            lon = raw.longitude
            variance = a * a
            lastTimeMs = tMs
        } else {
            val dtMs = tMs - lastTimeMs
            if (dtMs > 0) {
                variance += dtMs * Q_METRES_PER_SECOND * Q_METRES_PER_SECOND / 1000f
                lastTimeMs = tMs
            }
            val k = variance / (variance + a * a)
            lat += k * (raw.latitude - lat)
            lon += k * (raw.longitude - lon)
            variance = (1f - k) * variance
        }
        val out = Location(raw)
        out.latitude = lat
        out.longitude = lon
        out.accuracy = max(acc * 0.8f, sqrt(variance))
        return out
    }
}
