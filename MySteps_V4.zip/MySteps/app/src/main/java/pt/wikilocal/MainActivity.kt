package pt.wikilocal

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.config.Configuration
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import pt.wikilocal.data.TrackDatabase
import pt.wikilocal.data.TrackEntity
import java.io.File
import java.io.IOException
import java.util.Locale
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var mapView: MapView
    private lateinit var mapManager: MapManager

    private lateinit var tvInfo: TextView
    private lateinit var tvDistance: TextView
    private lateinit var tvTime: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var tvElevation: TextView
    private lateinit var tvElevStats: TextView
    private lateinit var tvGuidanceArrow: TextView
    private lateinit var tvGuidanceText: TextView
    private lateinit var guidanceBanner: View
    private lateinit var compass: CompassView
    private lateinit var controls: View
    private lateinit var recControls: View
    private lateinit var tvGps: TextView
    private lateinit var navControls: View
    private lateinit var btnPause: Button
    private lateinit var btnNavPause: Button
    private lateinit var btnNavReverse: Button

    private val engine = TrackerState.engine
    private val prefs by lazy { getSharedPreferences("mysteps", MODE_PRIVATE) }

    private var pendingAction: (() -> Unit)? = null
    private var exportTrackId = -1L
    private var centerOnNextFix = false
    private var approachCheckPending = false
    private var lastTouch = 0L

    // Localização ao abrir a app (pré-visualização, só enquanto não há gravação/navegação)
    private val locationManager by lazy { getSystemService(LOCATION_SERVICE) as LocationManager }
    private val gnssMonitor by lazy { GnssMonitor(this) }
    private var previewing = false

    private val previewListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            if (!serviceActive()) TrackerState.lastLocation.value = location
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        }

        override fun onProviderEnabled(provider: String) {
        }

        override fun onProviderDisabled(provider: String) {
        }
    }

    // Bússola
    private val sensorManager by lazy { getSystemService(SENSOR_SERVICE) as SensorManager }
    private var rotationSensor: Sensor? = null
    private var azimuthSmooth = 0f
    private var azimuthInit = false

    // ---------------------------------------------------------------- Activity Result API (SAF + permissões)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val action = pendingAction
            pendingAction = null
            if (hasFineLocation()) {
                startPreview()
                if (action != null) withLocation(action)
            } else if (action != null) {
                toast(R.string.perm_denied)
            }
        }

    private val openGpxLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) loadGpx(uri)
        }

    private val openMapLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importMbtiles(uri)
        }

    private val exportLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/gpx+xml")) { uri ->
            if (uri != null) exportTo(uri)
        }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()   // tem de vir antes de super.onCreate
        super.onCreate(savedInstanceState)
        configureOsmdroid()
        setContentView(R.layout.activity_main)

        mapView = findViewById(R.id.mapView)
        tvInfo = findViewById(R.id.tvInfo)
        tvDistance = findViewById(R.id.tvDistance)
        tvTime = findViewById(R.id.tvTime)
        tvSpeed = findViewById(R.id.tvSpeed)
        tvElevation = findViewById(R.id.tvElevation)
        tvElevStats = findViewById(R.id.tvElevStats)
        tvGuidanceArrow = findViewById(R.id.tvGuidanceArrow)
        tvGuidanceText = findViewById(R.id.tvGuidanceText)
        guidanceBanner = findViewById(R.id.guidanceBanner)
        compass = findViewById(R.id.compass)
        tvGps = findViewById(R.id.tvGps)
        controls = findViewById(R.id.controls)
        recControls = findViewById(R.id.recControls)
        navControls = findViewById(R.id.navControls)
        btnPause = findViewById(R.id.btnPause)
        btnNavPause = findViewById(R.id.btnNavPause)
        btnNavReverse = findViewById(R.id.btnNavReverse)

        TrackerState.voiceEnabled.value = prefs.getBoolean(KEY_VOICE, true)
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        mapManager = MapManager(this, mapView).also {
            it.init()
            it.onLongPress = { p -> onMapLongPress(p) }
        }
        // Se o utilizador mexer no mapa, o "seguir posição" pausa durante 10 s
        mapView.setOnTouchListener { _, _ ->
            lastTouch = SystemClock.elapsedRealtime()
            false
        }

        findViewById<Button>(R.id.btnRecord).setOnClickListener { onRecordClicked() }
        findViewById<Button>(R.id.btnNavigate).setOnClickListener { onNavigateClicked() }
        btnPause.setOnClickListener { onPauseClicked() }
        findViewById<Button>(R.id.btnStopRec).setOnClickListener { onStopRecordClicked() }
        findViewById<Button>(R.id.btnNavStop).setOnClickListener { onNavStopClicked() }
        btnNavPause.setOnClickListener { onNavPauseClicked() }
        btnNavReverse.setOnClickListener { onNavReverseClicked() }
        findViewById<Button>(R.id.btnOptions).setOnClickListener { showOptionsDialog() }
        findViewById<Button>(R.id.btnReverse).setOnClickListener { onReverseClicked() }
        findViewById<Button>(R.id.btnStartHere).setOnClickListener { onStartHereClicked() }
        findViewById<Button>(R.id.btnOpenGpx).setOnClickListener { openGpxLauncher.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.btnOpenMap).setOnClickListener { showMapSourceDialog() }
        findViewById<Button>(R.id.btnTracks).setOnClickListener { showTracks() }
        findViewById<Button>(R.id.btnLocate).setOnClickListener {
            val loc = TrackerState.lastLocation.value
            if (loc == null) toast(R.string.no_gps_fix)
            else mapManager.centerOn(GeoPoint(loc.latitude, loc.longitude))
        }

        restoreMapSource()
        applyMapTheme()
        redrawRoute()
        observeState()
        refreshUi()
        updateHud()

        // Ao abrir, o mapa mostra onde estamos (pede a permissão na primeira vez)
        centerOnNextFix = true
        centerOnLastKnown()
        if (!hasFineLocation()) permissionLauncher.launch(requiredPermissions())
    }

    override fun onResume() {
        super.onResume()
        mapManager.onResume()
        rotationSensor?.let {
            sensorManager.registerListener(compassListener, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        sensorManager.unregisterListener(compassListener)
        mapManager.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        mapManager.onDestroy()
        super.onDestroy()
    }

    private fun configureOsmdroid() {
        val cfg = Configuration.getInstance()
        cfg.load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))
        cfg.userAgentValue = packageName
        val base = File(filesDir, "osmdroid").apply { mkdirs() }
        val cache = File(filesDir, "osmdroid/tiles").apply { mkdirs() }
        cfg.osmdroidBasePath = base
        cfg.osmdroidTileCache = cache
        cfg.tileFileSystemCacheMaxBytes = 1024L * 1024 * 1024
        cfg.tileFileSystemCacheTrimBytes = 800L * 1024 * 1024
    }

    // ---------------------------------------------------------------- bússola

    private val compassListener = object : SensorEventListener {
        private val rot = FloatArray(9)
        private val remapped = FloatArray(9)
        private val ori = FloatArray(3)

        override fun onSensorChanged(event: SensorEvent) {
            SensorManager.getRotationMatrixFromVector(rot, event.values)
            SensorManager.getOrientation(rot, ori)
            var az = ori[0]
            if (abs(ori[1]) > 0.8f) {
                // telemóvel na vertical (posição normal de caminhada)
                SensorManager.remapCoordinateSystem(rot, SensorManager.AXIS_X, SensorManager.AXIS_Z, remapped)
                SensorManager.getOrientation(remapped, ori)
                az = ori[0]
            }
            val deg = ((Math.toDegrees(az.toDouble()) + 360.0) % 360.0).toFloat()
            if (!azimuthInit) {
                azimuthSmooth = deg
                azimuthInit = true
            } else {
                val delta = ((deg - azimuthSmooth + 540f) % 360f) - 180f
                azimuthSmooth = (azimuthSmooth + 0.15f * delta + 360f) % 360f
            }
            compass.setAzimuth(azimuthSmooth)
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        }
    }

    // ---------------------------------------------------------------- estado do serviço -> UI

    private fun observeState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    TrackerState.recordedPoints.collect {
                        mapManager.showRecordedTrack(it)
                    }
                }
                launch { TrackerState.recording.collect { refreshUi() } }
                launch { TrackerState.paused.collect { refreshUi() } }
                launch { TrackerState.navigating.collect { refreshUi() } }
                launch { TrackerState.navPaused.collect { refreshUi() } }
                launch { TrackerState.gnss.collect { updateHud() } }
                launch { TrackerState.elevation.collect { updateHud() } }
                launch {
                    // Sem gravação/navegação: o próprio ecrã obtém a posição; caso contrário fá-lo o serviço
                    try {
                        combine(TrackerState.recording, TrackerState.navigating) { r, n -> r || n }
                            .collect { active -> if (active) stopPreview() else startPreview() }
                    } finally {
                        stopPreview()
                    }
                }
                launch { TrackerState.navStatus.collect { refreshUi() } }
                launch { TrackerState.guidance.collect { updateGuidance() } }
                launch { TrackerState.routeVersion.collect { redrawRoute() } }
                launch { TrackerState.lastLocation.collect { onLocation(it) } }
                launch { TrackerState.distanceMeters.collect { updateHud() } }
                launch {
                    while (true) {          // relógio do HUD + tema automático dia/noite
                        updateHud()
                        applyMapTheme()
                        delay(1000)
                    }
                }
            }
        }
    }

    private fun onLocation(loc: Location?) {
        if (loc == null) {
            mapManager.updateMyPosition(null)
            updateHud()
            return
        }
        val gp = GeoPoint(loc.latitude, loc.longitude)
        mapManager.updateMyPosition(gp)

        val active = TrackerState.recording.value || TrackerState.navigating.value
        if (centerOnNextFix) {
            if (loc.ageMs() < 60_000L) centerOnNextFix = false   // fix recente: já está centrado
            mapManager.centerOn(gp)
        } else if (active && SystemClock.elapsedRealtime() - lastTouch > 10_000L) {
            mapManager.follow(gp)
        }
        if (rotationSensor == null && loc.hasBearing()) compass.setAzimuth(loc.bearing)

        checkApproach(gp)
        updateHud()
    }

    private fun updateHud() {
        tvDistance.text = String.format(Locale.getDefault(), "%.2f km", TrackerState.distanceMeters.value / 1000.0)
        val total = TrackerState.clock.value.elapsed() / 1000
        tvTime.text = String.format(Locale.getDefault(), "%d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60)

        val loc = TrackerState.lastLocation.value
        if (loc != null && loc.hasSpeed()) {
            val kmh = if (loc.speed < 0.5f) 0.0 else loc.speed * 3.6
            tvSpeed.text = getString(R.string.hud_speed, kmh)
        } else {
            tvSpeed.setText(R.string.hud_speed_none)
        }
        val alt = loc?.bestAltitude()
        if (alt != null) tvElevation.text = getString(R.string.hud_elevation, Math.round(alt).toInt())
        else tvElevation.setText(R.string.hud_elevation_none)

        val e = TrackerState.elevation.value
        tvElevStats.text = getString(R.string.hud_elev_stats, Math.round(e.gain).toInt(), Math.round(e.loss).toInt())

        // Qualidade do sinal GPS
        if (!(serviceActive() || previewing)) {
            tvGps.visibility = View.GONE
        } else {
            val g = TrackerState.gnss.value
            tvGps.visibility = View.VISIBLE
            when {
                loc == null -> {
                    tvGps.text = getString(R.string.gps_searching, g.used, g.visible)
                    tvGps.setTextColor(0xFFFFB74D.toInt())
                }
                loc.ageMs() > 20_000L -> {
                    tvGps.text = getString(R.string.gps_lost, g.used, g.visible)
                    tvGps.setTextColor(0xFFFF5252.toInt())
                }
                else -> {
                    val acc = Math.round(loc.accuracy)
                    tvGps.text = getString(R.string.gps_status, acc, g.used, g.visible)
                    tvGps.setTextColor(
                        when {
                            acc <= 10 -> 0xFF81C784.toInt()
                            acc <= 25 -> 0xFFFFEE58.toInt()
                            else -> 0xFFFF8A65.toInt()
                        }
                    )
                }
            }
        }
    }

    private fun updateGuidance() {
        val nav = TrackerState.navigating.value
        guidanceBanner.visibility = if (nav) View.VISIBLE else View.GONE
        if (!nav) {
            compass.setTarget(null)
            return
        }
        if (TrackerState.navPaused.value) {
            tvGuidanceArrow.text = "⏸"
            tvGuidanceText.setText(R.string.nav_paused_banner)
            compass.setTarget(null)
            return
        }
        val g = TrackerState.guidance.value
        if (g == null) {
            tvGuidanceArrow.text = "◎"
            tvGuidanceText.setText(R.string.info_wait_gps)
            compass.setTarget(null)
        } else {
            tvGuidanceArrow.text = g.arrow
            tvGuidanceText.text = g.text
            compass.setTarget(g.targetBearing?.toFloat())
        }
    }

    private fun refreshUi() {
        val recording = TrackerState.recording.value
        val paused = TrackerState.paused.value
        val navigating = TrackerState.navigating.value

        val navPaused = TrackerState.navPaused.value

        // Em gravação: só "Pausa" e "Parar gravação"
        // Em navegação: só "Parar", "Pausar" e (em pausa) "Inverter"
        controls.visibility = if (recording || navigating) View.GONE else View.VISIBLE
        recControls.visibility = if (recording) View.VISIBLE else View.GONE
        navControls.visibility = if (navigating && !recording) View.VISIBLE else View.GONE
        btnPause.setText(if (paused) R.string.btn_resume else R.string.btn_pause)
        btnNavPause.setText(if (navPaused) R.string.btn_nav_resume else R.string.btn_nav_pause)
        btnNavReverse.visibility = if (navPaused) View.VISIBLE else View.GONE
        updateGuidance()

        val lines = ArrayList<String>()
        if (engine.isLoaded) {
            val dir = getString(if (engine.reversed) R.string.dir_reverse else R.string.dir_forward)
            lines += if (engine.routeGain > 0.0 || engine.routeLoss > 0.0) {
                getString(
                    R.string.info_route_elev, engine.name, engine.totalMeters / 1000.0,
                    Math.round(engine.routeGain).toInt(), Math.round(engine.routeLoss).toInt(), dir
                )
            } else {
                getString(R.string.info_route, engine.name, engine.totalMeters / 1000.0, dir)
            }
        }
        if (paused) lines += getString(R.string.info_paused)
        if (navigating && navPaused) lines += getString(R.string.info_nav_paused)
        if (navigating) {
            val st = TrackerState.navStatus.value
            if (st != null && !st.arrived) {
                lines += if (st.remainingGain > 0.0 || st.remainingLoss > 0.0) {
                    getString(
                        R.string.info_nav_elev, st.remaining / 1000.0, (st.progress * 100).toInt(),
                        Math.round(st.remainingGain).toInt(), Math.round(st.remainingLoss).toInt()
                    )
                } else {
                    getString(R.string.info_nav, st.remaining / 1000.0, (st.progress * 100).toInt())
                }
            }
        }
        tvInfo.text = lines.joinToString("\n")
        tvInfo.visibility = if (lines.isEmpty()) View.GONE else View.VISIBLE
    }

    // ---------------------------------------------------------------- botões

    private fun onRecordClicked() {
        withLocation {
            centerOnNextFix = true
            startFg(TrackRecordingService.ACTION_START_RECORDING)
        }
    }

    private fun onPauseClicked() {
        sendToService(
            if (TrackerState.paused.value) TrackRecordingService.ACTION_RESUME_RECORDING
            else TrackRecordingService.ACTION_PAUSE_RECORDING
        )
    }

    private fun onStopRecordClicked() {
        AlertDialog.Builder(this)
            .setTitle(R.string.stop_record_title)
            .setMessage(R.string.stop_record_msg)
            .setPositiveButton(R.string.btn_stop_record) { _, _ ->
                sendToService(TrackRecordingService.ACTION_STOP_RECORDING)
                toast(R.string.track_saved)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun onNavStopClicked() {
        AlertDialog.Builder(this)
            .setTitle(R.string.nav_stop_title)
            .setMessage(R.string.nav_stop_msg)
            .setPositiveButton(R.string.btn_nav_stop) { _, _ ->
                sendToService(TrackRecordingService.ACTION_STOP_NAVIGATION)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun onNavPauseClicked() {
        sendToService(
            if (TrackerState.navPaused.value) TrackRecordingService.ACTION_RESUME_NAVIGATION
            else TrackRecordingService.ACTION_PAUSE_NAVIGATION
        )
    }

    /** Só disponível em pausa: inverte o sentido a partir da posição atual (para voltar para trás). */
    private fun onNavReverseClicked() {
        val loc = TrackerState.lastLocation.value
        if (loc != null && loc.ageMs() < 60_000L) {
            engine.setStartNearest(GeoPoint(loc.latitude, loc.longitude))
        }
        engine.toggleReverse()
        afterRouteChanged(zoom = false)
        toast(R.string.nav_reversed)
    }

    private fun onNavigateClicked() {
        if (!engine.isLoaded) {
            toast(R.string.no_route)
        } else {
            withLocation {
                centerOnNextFix = true
                approachCheckPending = true
                startFg(TrackRecordingService.ACTION_START_NAVIGATION)
                TrackerState.lastLocation.value?.takeIf { it.ageMs() < 60_000L }
                    ?.let { checkApproach(GeoPoint(it.latitude, it.longitude)) }
            }
        }
    }

    // ---------------------------------------------------------------- opções / tema do mapa

    private fun toggleVoice() {
        val v = !TrackerState.voiceEnabled.value
        TrackerState.voiceEnabled.value = v
        prefs.edit().putBoolean(KEY_VOICE, v).apply()
    }

    private fun showOptionsDialog() {
        val items = arrayOf(
            getString(R.string.opt_map_color),
            getString(if (TrackerState.voiceEnabled.value) R.string.opt_voice_on else R.string.opt_voice_off)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_options)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> showMapColorDialog()
                    1 -> toggleVoice()
                }
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    private fun showMapColorDialog() {
        val modes = arrayOf(getString(R.string.map_color_auto), getString(R.string.map_color_dark))
        val current = if (prefs.getString(KEY_MAP_THEME, "auto") == "dark") 1 else 0
        AlertDialog.Builder(this)
            .setTitle(R.string.opt_map_color)
            .setSingleChoiceItems(modes, current) { dialog, which ->
                prefs.edit().putString(KEY_MAP_THEME, if (which == 1) "dark" else "auto").apply()
                applyMapTheme()
                dialog.dismiss()
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    /** Automático: escuro quando o Sol está abaixo do horizonte no local atual; Escuro: sempre. */
    private fun applyMapTheme() {
        val dark = if (prefs.getString(KEY_MAP_THEME, "auto") == "dark") {
            true
        } else {
            val loc = TrackerState.lastLocation.value
            val c = mapView.mapCenter
            SunCalc.isNight(loc?.latitude ?: c.latitude, loc?.longitude ?: c.longitude)
        }
        mapManager.setDarkMode(dark)
    }

    // ---------------------------------------------------------------- localização ao abrir (pré-visualização)

    private fun serviceActive(): Boolean = TrackerState.recording.value || TrackerState.navigating.value

    /** Usa a última posição conhecida para mostrar logo o mapa onde estamos. */
    @SuppressLint("MissingPermission")
    private fun centerOnLastKnown() {
        if (!hasFineLocation()) return
        try {
            val last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: return
            if (TrackerState.lastLocation.value == null) TrackerState.lastLocation.value = last
        } catch (e: Exception) {
            // sem posição conhecida
        }
    }

    @SuppressLint("MissingPermission")
    private fun startPreview() {
        if (previewing || serviceActive() || !hasFineLocation()) return
        if (!locationManager.allProviders.contains(LocationManager.GPS_PROVIDER)) return
        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, 2000L, 0f, previewListener, Looper.getMainLooper()
            )
            previewing = true
            gnssMonitor.start()
            centerOnLastKnown()
        } catch (e: Exception) {
            previewing = false
        }
    }

    private fun stopPreview() {
        if (!previewing) return
        try {
            locationManager.removeUpdates(previewListener)
        } catch (e: Exception) {
            // ignorar
        }
        gnssMonitor.stop()
        previewing = false
    }

    private fun onReverseClicked() {
        if (!engine.isLoaded) {
            toast(R.string.no_route)
            return
        }
        engine.toggleReverse()
        afterRouteChanged(zoom = false)
    }

    private fun onStartHereClicked() {
        if (!engine.isLoaded) {
            toast(R.string.no_route)
            return
        }
        val loc = TrackerState.lastLocation.value
        if (loc == null || loc.ageMs() > 60_000L) {
            toast(R.string.no_gps_fix)
            return
        }
        val d = engine.setStartNearest(GeoPoint(loc.latitude, loc.longitude))
        afterRouteChanged(zoom = false)
        toast(R.string.start_set, d.toInt())
    }

    private fun onMapLongPress(p: GeoPoint) {
        if (!engine.isLoaded) return
        val d = engine.setStartNearest(p)
        afterRouteChanged(zoom = false)
        toast(R.string.start_set, d.toInt())
    }

    private fun redrawRoute() {
        mapManager.showRoute(engine.fullPath, engine.activePath)
        mapManager.showStartMarker(engine.startPoint)
    }

    private fun afterRouteChanged(zoom: Boolean) {
        redrawRoute()
        if (zoom) mapManager.zoomTo(engine.fullPath)
        TrackerState.navStatus.value = null
        TrackerState.routeVersion.update { it + 1 }   // avisa o serviço (reinicia anúncios de voz)
        refreshUi()
    }

    // ---------------------------------------------------------------- chegar ao início do percurso

    /** Ao iniciar a navegação: se estiver longe do percurso, oferece indicações (Google Maps / Waze) até ao início. */
    private fun checkApproach(gp: GeoPoint) {
        if (!approachCheckPending || !TrackerState.navigating.value || !engine.isLoaded) return
        approachCheckPending = false
        val hit = engine.nearestOnRoute(gp) ?: return
        if (hit.distance <= RouteEngine.NEAR_METERS) return    // no percurso ou perto: a app guia diretamente
        val start = engine.startPoint ?: return
        val dist = GeoMath.distance(gp, start)

        AlertDialog.Builder(this)
            .setTitle(R.string.approach_title)
            .setMessage(getString(R.string.approach_msg, formatDistance(dist)))
            .setPositiveButton(R.string.nav_google) { _, _ -> openExternalNavigation(start, waze = false) }
            .setNeutralButton(R.string.nav_waze) { _, _ -> openExternalNavigation(start, waze = true) }
            .setNegativeButton(R.string.nav_no, null)
            .show()
    }

    private fun openExternalNavigation(p: GeoPoint, waze: Boolean) {
        val lat = p.latitude
        val lon = p.longitude
        val intent = if (waze) {
            Intent(Intent.ACTION_VIEW, Uri.parse("waze://?ll=$lat,$lon&navigate=yes"))
        } else {
            Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$lat,$lon"))
                .setPackage("com.google.android.apps.maps")
        }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon")))
            } catch (e2: ActivityNotFoundException) {
                toast(R.string.no_nav_app)
            }
        }
    }

    private fun formatDistance(m: Double): String =
        if (m >= 1000.0) String.format(Locale.getDefault(), "%.1f km", m / 1000.0)
        else String.format(Locale.getDefault(), "%d m", Math.round(m / 10.0) * 10)

    // ---------------------------------------------------------------- permissões / GPS / serviço

    private fun hasFineLocation(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    private fun requiredPermissions(): Array<String> {
        val list = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
        return list.toTypedArray()
    }

    private fun withLocation(action: () -> Unit) {
        if (!hasFineLocation()) {
            pendingAction = action
            permissionLauncher.launch(requiredPermissions())
            return
        }
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            AlertDialog.Builder(this)
                .setTitle(R.string.gps_disabled_title)
                .setMessage(R.string.gps_disabled_msg)
                .setPositiveButton(R.string.open_settings) { _, _ ->
                    startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
            return
        }
        action()
    }

    private fun startFg(action: String) {
        ContextCompat.startForegroundService(
            this, Intent(this, TrackRecordingService::class.java).setAction(action)
        )
    }

    private fun sendToService(action: String) {
        startService(Intent(this, TrackRecordingService::class.java).setAction(action))
    }

    // ---------------------------------------------------------------- GPX

    private fun loadGpx(uri: Uri) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching { contentResolver.openInputStream(uri)!!.use { GpxParser.parse(it) } }
            }
            result.onSuccess { gpx ->
                if (gpx.points.size < 2) {
                    toast(R.string.route_invalid)
                } else {
                    val name = gpx.name ?: displayName(uri) ?: "GPX"
                    loadRoute(name, gpx.points)
                    toast(R.string.route_loaded, name)
                }
            }.onFailure {
                toast(R.string.route_invalid)
            }
        }
    }

    private fun loadRoute(name: String, points: List<GeoPoint>) {
        engine.load(name, points)
        afterRouteChanged(zoom = true)
    }

    private fun displayName(uri: Uri): String? =
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }

    // ---------------------------------------------------------------- fontes de mapa

    private fun showMapSourceDialog() {
        val items = arrayOf(
            getString(R.string.src_osm),
            getString(R.string.src_topo),
            getString(R.string.src_offline_file),
            getString(R.string.src_offline_last)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_open_map)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> useOnline(MapManager.OnlineSource.OSM)
                    1 -> useOnline(MapManager.OnlineSource.TOPO)
                    2 -> openMapLauncher.launch(arrayOf("*/*"))
                    3 -> if (!loadSavedMbtiles()) toast(R.string.no_saved_map)
                }
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    private fun useOnline(src: MapManager.OnlineSource) {
        mapManager.useOnline(src)
        prefs.edit().putString(KEY_SOURCE, if (src == MapManager.OnlineSource.OSM) "osm" else "topo").apply()
        updateAttribution()
    }

    /** Ao arrancar: repõe a última fonte usada (por omissão, OpenStreetMap online). */
    private fun restoreMapSource() {
        when (prefs.getString(KEY_SOURCE, "osm")) {
            "mbtiles" -> if (!loadSavedMbtiles(silent = true)) useOnline(MapManager.OnlineSource.OSM)
            "topo" -> useOnline(MapManager.OnlineSource.TOPO)
            else -> useOnline(MapManager.OnlineSource.OSM)
        }
    }

    private fun loadSavedMbtiles(silent: Boolean = false): Boolean {
        val path = prefs.getString(KEY_MAP, null) ?: return false
        val file = File(path)
        if (!file.exists()) return false
        return try {
            val info = mapManager.loadMbtiles(file)
            prefs.edit().putString(KEY_SOURCE, "mbtiles").apply()
            info.bounds?.let { mapManager.zoomToBox(it) }
            updateAttribution()
            true
        } catch (e: Exception) {
            mapManager.clearOfflineMap()
            if (!silent) toast(R.string.map_invalid, e.message ?: "")
            false
        }
    }

    private fun updateAttribution() {
        val tv = findViewById<TextView>(R.id.tvAttribution)
        when (prefs.getString(KEY_SOURCE, "osm")) {
            "mbtiles" -> tv.visibility = View.GONE
            "topo" -> {
                tv.setText(R.string.attr_topo)
                tv.visibility = View.VISIBLE
            }
            else -> {
                tv.setText(R.string.attr_osm)
                tv.visibility = View.VISIBLE
            }
        }
    }

    /**
     * O SAF devolve um content:// URI. O OSMDroid precisa de um caminho de ficheiro para abrir o SQLite,
     * por isso o MBTiles é copiado para o armazenamento privado da app (sem permissões de armazenamento).
     */
    private fun importMbtiles(uri: Uri) {
        val mapsDir = File(filesDir, "maps").apply { mkdirs() }
        val target = File(mapsDir, "offline.mbtiles")
        val tmp = File(mapsDir, "import.tmp")
        val dialog = AlertDialog.Builder(this)
            .setMessage(R.string.map_copying)
            .setCancelable(false)
            .show()

        lifecycleScope.launch {
            try {
                val info = withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)!!.use { input ->
                        tmp.outputStream().use { out -> input.copyTo(out, 1 shl 16) }
                    }
                    MapManager.readInfo(tmp)          // valida antes de substituir o mapa atual
                }
                mapManager.clearOfflineMap()           // fecha o SQLite anterior
                withContext(Dispatchers.IO) {
                    target.delete()
                    if (!tmp.renameTo(target)) throw IOException("rename")
                }
                mapManager.loadMbtiles(target)
                prefs.edit().putString(KEY_MAP, target.absolutePath).putString(KEY_SOURCE, "mbtiles").apply()
                updateAttribution()
                toast(R.string.map_loaded, info.minZoom, info.maxZoom)
                info.bounds?.let { mapManager.zoomToBox(it) }
            } catch (e: Exception) {
                tmp.delete()
                toast(R.string.map_invalid, e.message ?: "")
                if (!mapManager.hasOfflineMap) restoreMapSource()
            } finally {
                dialog.dismiss()
                refreshUi()
            }
        }
    }

    // ---------------------------------------------------------------- gravações

    private fun showTracks() {
        lifecycleScope.launch {
            val tracks = withContext(Dispatchers.IO) {
                TrackDatabase.get(applicationContext).trackDao().getAllTracks()
            }
            if (tracks.isEmpty()) {
                toast(R.string.tracks_empty)
                return@launch
            }
            val labels = tracks.map {
                if (it.elevationGain > 0.0) {
                    getString(
                        R.string.track_item_elev, it.name, it.distanceMeters / 1000.0,
                        Math.round(it.elevationGain).toInt()
                    )
                } else {
                    getString(R.string.track_item, it.name, it.distanceMeters / 1000.0)
                }
            }.toTypedArray()
            AlertDialog.Builder(this@MainActivity)
                .setTitle(R.string.tracks_title)
                .setItems(labels) { _, i -> showTrackActions(tracks[i]) }
                .setNegativeButton(R.string.close, null)
                .show()
        }
    }

    private fun showTrackActions(t: TrackEntity) {
        val actions = arrayOf(
            getString(R.string.act_load),
            getString(R.string.act_rename),
            getString(R.string.act_export),
            getString(R.string.act_delete)
        )
        AlertDialog.Builder(this)
            .setTitle(t.name)
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> loadTrackAsRoute(t)
                    1 -> showRenameDialog(t)
                    2 -> {
                        exportTrackId = t.id
                        exportLauncher.launch(t.name.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".gpx")
                    }
                    3 -> confirmDelete(t)
                }
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    private fun showRenameDialog(t: TrackEntity) {
        val input = EditText(this).apply {
            setText(t.name)
            setSelectAllOnFocus(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val container = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(
                input,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.rename_title)
            .setView(container)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    lifecycleScope.launch(Dispatchers.IO) {
                        TrackDatabase.get(applicationContext).trackDao().renameTrack(t.id, name)
                    }
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun loadTrackAsRoute(t: TrackEntity) {
        lifecycleScope.launch {
            val pts = withContext(Dispatchers.IO) {
                TrackDatabase.get(applicationContext).trackDao().getPoints(t.id)
                    .map { GeoPoint(it.latitude, it.longitude, it.altitude ?: 0.0) }
            }
            if (pts.size < 2) {
                toast(R.string.route_invalid)
            } else {
                loadRoute(t.name, pts)
                toast(R.string.route_loaded, t.name)
            }
        }
    }

    private fun confirmDelete(t: TrackEntity) {
        AlertDialog.Builder(this)
            .setMessage(R.string.delete_confirm)
            .setPositiveButton(R.string.act_delete) { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) {
                    TrackDatabase.get(applicationContext).trackDao().deleteTrack(t.id)
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun exportTo(uri: Uri) {
        val id = exportTrackId
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val dao = TrackDatabase.get(applicationContext).trackDao()
                    val track = dao.getTrack(id) ?: throw IllegalStateException("?")
                    val points = dao.getPoints(id)
                    contentResolver.openOutputStream(uri)!!.use { GpxParser.write(track.name, points, it) }
                }
            }
            result.onSuccess { toast(R.string.exported) }
                .onFailure { toast(R.string.export_error, it.message ?: "") }
        }
    }

    // ---------------------------------------------------------------- util

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun toast(@StringRes id: Int, vararg args: Any) = toast(getString(id, *args))

    companion object {
        private const val KEY_MAP = "mbtiles_path"
        private const val KEY_SOURCE = "map_source"
        private const val KEY_VOICE = "voice_enabled"
        private const val KEY_MAP_THEME = "map_theme"
    }
}
