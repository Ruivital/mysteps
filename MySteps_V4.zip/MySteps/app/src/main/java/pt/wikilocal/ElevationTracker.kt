package pt.wikilocal

/**
 * Acumula subida/descida sem somar ruído:
 *  1. suaviza a altitude (filtro exponencial, [alpha]);
 *  2. só conta uma variação quando se afasta mais de [thresholdM] da altitude de referência (histerese).
 *
 * Valores usados: GPS (ruidoso) -> limiar 5 m; barómetro (muito estável) -> limiar 2 m.
 */
class ElevationTracker(private val thresholdM: Double, private val alpha: Double) {

    var gain = 0.0
        private set
    var loss = 0.0
        private set
    var samples = 0
        private set

    private var smooth = Double.NaN
    private var reference = Double.NaN

    fun reset() {
        gain = 0.0
        loss = 0.0
        samples = 0
        smooth = Double.NaN
        reference = Double.NaN
    }

    fun add(altitude: Double) {
        if (altitude.isNaN()) return
        samples++
        if (smooth.isNaN()) {
            smooth = altitude
            reference = altitude
            return
        }
        smooth += alpha * (altitude - smooth)
        val diff = smooth - reference
        if (diff >= thresholdM) {
            gain += diff
            reference = smooth
        } else if (diff <= -thresholdM) {
            loss += -diff
            reference = smooth
        }
    }
}
