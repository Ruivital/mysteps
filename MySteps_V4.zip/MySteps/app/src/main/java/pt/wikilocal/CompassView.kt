package pt.wikilocal

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

/** Bússola simples: agulha vermelha aponta ao norte; triângulo azul na borda indica o rumo a seguir. */
class CompassView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var azimuth = 0f
    private var target: Float? = null
    private val dp = resources.displayMetrics.density

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0x66000000
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * dp
        color = 0xFFFFFFFF.toInt()
    }
    private val northPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFFE53935.toInt()
    }
    private val southPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFFFFFFFF.toInt()
    }
    private val targetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF29B6F6.toInt()
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
        textSize = 12f * resources.displayMetrics.scaledDensity
    }
    private val needle = Path()

    fun setAzimuth(deg: Float) {
        azimuth = deg
        invalidate()
    }

    fun setTarget(deg: Float?) {
        target = deg
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(cx, cy) - 3f * dp
        canvas.drawCircle(cx, cy, r, bgPaint)
        canvas.drawCircle(cx, cy, r, ringPaint)

        canvas.save()
        canvas.rotate(-azimuth, cx, cy)

        // agulha
        needle.reset()
        needle.moveTo(cx, cy - r * 0.62f)
        needle.lineTo(cx - r * 0.20f, cy)
        needle.lineTo(cx + r * 0.20f, cy)
        needle.close()
        canvas.drawPath(needle, northPaint)
        needle.reset()
        needle.moveTo(cx, cy + r * 0.62f)
        needle.lineTo(cx - r * 0.20f, cy)
        needle.lineTo(cx + r * 0.20f, cy)
        needle.close()
        canvas.drawPath(needle, southPaint)
        canvas.drawText("N", cx, cy - r * 0.70f, textPaint)

        // rumo a seguir
        target?.let { t ->
            canvas.save()
            canvas.rotate(t, cx, cy)
            needle.reset()
            needle.moveTo(cx, cy - r)
            needle.lineTo(cx - r * 0.16f, cy - r * 0.80f)
            needle.lineTo(cx + r * 0.16f, cy - r * 0.80f)
            needle.close()
            canvas.drawPath(needle, targetPaint)
            canvas.restore()
        }
        canvas.restore()
    }
}
