package pt.wikilocal

import android.location.Location
import android.os.Build
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import org.osmdroid.util.GeoPoint

/** Idade do fix em milissegundos. */
fun Location.ageMs(): Long =
    (SystemClock.elapsedRealtimeNanos() - elapsedRealtimeNanos) / 1_000_000L

/** Altitude "acima do nível do mar" quando o Android 14+ a fornece; caso contrário a altitude GPS (elipsoide). */
fun Location.bestAltitude(): Double? {
    if (Build.VERSION.SDK_INT >= 34 && hasMslAltitude()) return mslAltitudeMeters
    return if (hasAltitude()) altitude else null
}

/** Estado partilhado entre o serviço e a UI (mesmo processo, sempre na thread principal para o motor de rotas). */
object TrackerState {

    data class Clock(
        val accumulatedMs: Long = 0,
        val segmentStart: Long = 0,
        val running: Boolean = false
    ) {
        fun elapsed(now: Long = SystemClock.elapsedRealtime()): Long =
            accumulatedMs + if (running) now - segmentStart else 0L
    }

    /** Subida e descida acumuladas (m). */
    data class Elevation(val gain: Double = 0.0, val loss: Double = 0.0)

    /** Satélites usados no fix / visíveis. */
    data class Gnss(val used: Int = 0, val visible: Int = 0)

    /** Instrução de navegação mostrada no ecrã (e dita em voz). */
    data class Guidance(val arrow: String, val text: String, val targetBearing: Double?)

    val recording = MutableStateFlow(false)
    val paused = MutableStateFlow(false)
    val navigating = MutableStateFlow(false)
    val navPaused = MutableStateFlow(false)
    val gnss = MutableStateFlow(Gnss())
    val elevation = MutableStateFlow(Elevation())
    val lastLocation = MutableStateFlow<Location?>(null)
    val recordedPoints = MutableStateFlow<List<GeoPoint>>(emptyList())
    val distanceMeters = MutableStateFlow(0.0)
    val clock = MutableStateFlow(Clock())

    val navStatus = MutableStateFlow<RouteEngine.Status?>(null)
    val guidance = MutableStateFlow<Guidance?>(null)
    val routeVersion = MutableStateFlow(0)
    val voiceEnabled = MutableStateFlow(true)

    /** Motor de percurso partilhado (UI escolhe início/sentido; serviço calcula a navegação). */
    val engine = RouteEngine()
}
