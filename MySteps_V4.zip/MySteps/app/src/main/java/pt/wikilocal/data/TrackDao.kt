package pt.wikilocal.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface TrackDao {

    @Insert
    suspend fun insertTrack(track: TrackEntity): Long

    @Insert
    suspend fun insertPoint(point: TrackPointEntity): Long

    @Query(
        "UPDATE tracks SET endTime = :endTime, distanceMeters = :distance, " +
            "elevationGain = :gain, elevationLoss = :loss WHERE id = :id"
    )
    suspend fun finishTrack(id: Long, endTime: Long, distance: Double, gain: Double, loss: Double)

    @Query("SELECT * FROM tracks ORDER BY startTime DESC")
    suspend fun getAllTracks(): List<TrackEntity>

    @Query("SELECT * FROM tracks WHERE id = :id")
    suspend fun getTrack(id: Long): TrackEntity?

    @Query("SELECT * FROM track_points WHERE trackId = :trackId ORDER BY id ASC")
    suspend fun getPoints(trackId: Long): List<TrackPointEntity>

    @Query("UPDATE tracks SET name = :name WHERE id = :id")
    suspend fun renameTrack(id: Long, name: String)

    @Query("DELETE FROM tracks WHERE id = :id")
    suspend fun deleteTrack(id: Long)
}
