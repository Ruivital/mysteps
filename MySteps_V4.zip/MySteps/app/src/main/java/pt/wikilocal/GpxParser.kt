package pt.wikilocal

import android.util.Xml
import org.osmdroid.util.GeoPoint
import org.xmlpull.v1.XmlPullParser
import pt.wikilocal.data.TrackPointEntity
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.GregorianCalendar
import java.util.Locale
import java.util.TimeZone

// ----------------------------------------------------------------------------- modelo

data class GpxPoint(val lat: Double, val lon: Double, val ele: Double?, val timeMs: Long?)

/** Um <trkseg> (ou uma <rte>): sequência contínua de pontos. */
data class GpxSegment(val points: List<GpxPoint>)

data class GpxTrackData(val name: String?, val segments: List<GpxSegment>)

data class GpxWaypoint(val name: String?, val description: String?, val point: GpxPoint)

data class GpxData(
    val name: String?,
    val tracks: List<GpxTrackData>,
    val routes: List<GpxSegment>,
    val waypoints: List<GpxWaypoint>
) {
    val trackPointCount: Int get() = tracks.sumOf { t -> t.segments.sumOf { it.points.size } }
}

/** Vista simples usada pela UI/motor de percursos (todos os segmentos concatenados). */
data class GpxTrack(val name: String?, val points: List<GeoPoint>)

/**
 * Parser GPX em streaming (XmlPullParser): nunca carrega o documento inteiro em memória,
 * só os pontos que vai devolvendo. Suporta <metadata>, <wpt>, <trk>/<trkseg>/<trkpt> e <rte>/<rtept>,
 * com <ele> e <time> (ISO 8601 com ou sem frações e fuso horário).
 */
object GpxParser {

    /** Limite de segurança contra ficheiros gigantes/maliciosos. */
    const val DEFAULT_MAX_POINTS = 500_000

    private val TIME_RE = Regex(
        """^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:?\d{2})?$"""
    )

    private enum class Kind { TRKPT, RTEPT, WPT }

    /** Lê o GPX completo (tracks, segmentos, rotas e waypoints). */
    fun parseFull(input: InputStream, maxPoints: Int = DEFAULT_MAX_POINTS): GpxData {
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(input, null)

        var docName: String? = null
        val tracks = ArrayList<GpxTrackData>()
        val routes = ArrayList<GpxSegment>()
        val waypoints = ArrayList<GpxWaypoint>()

        var inMetadata = false
        var inTrk = false
        var inSeg = false
        var inRte = false
        var curTrkName: String? = null
        var curSegments = ArrayList<GpxSegment>()
        var curPoints = ArrayList<GpxPoint>()

        var kind: Kind? = null
        var lat: Double? = null
        var lon: Double? = null
        var ele: Double? = null
        var time: Long? = null
        var wptName: String? = null
        var wptDesc: String? = null
        var total = 0

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name) {
                    "metadata" -> inMetadata = true
                    "trk" -> {
                        inTrk = true
                        curTrkName = null
                        curSegments = ArrayList()
                    }
                    "trkseg" -> {
                        inSeg = true
                        curPoints = ArrayList()
                    }
                    "rte" -> {
                        inRte = true
                        curPoints = ArrayList()
                    }
                    "trkpt", "rtept", "wpt" -> {
                        kind = when (parser.name) {
                            "trkpt" -> Kind.TRKPT
                            "rtept" -> Kind.RTEPT
                            else -> Kind.WPT
                        }
                        lat = parser.getAttributeValue(null, "lat")?.trim()?.toDoubleOrNull()
                        lon = parser.getAttributeValue(null, "lon")?.trim()?.toDoubleOrNull()
                        ele = null
                        time = null
                        wptName = null
                        wptDesc = null
                    }
                    "ele" -> if (kind != null) ele = parser.nextText().trim().toDoubleOrNull()
                    "time" -> if (kind != null) time = parseTime(parser.nextText())
                    "desc" -> if (kind == Kind.WPT) wptDesc = parser.nextText().trim().ifBlank { null }
                    "name" -> {
                        val t = parser.nextText().trim()
                        if (t.isNotEmpty()) {
                            when {
                                kind == Kind.WPT -> wptName = t
                                kind != null -> Unit                       // nome de um ponto de rota: ignorar
                                inTrk && !inSeg -> if (curTrkName == null) curTrkName = t
                                inMetadata -> if (docName == null) docName = t
                            }
                        }
                    }
                }
            } else if (event == XmlPullParser.END_TAG) {
                when (parser.name) {
                    "metadata" -> inMetadata = false
                    "trkpt", "rtept", "wpt" -> {
                        val la = lat
                        val lo = lon
                        val k = kind
                        if (k != null && la != null && lo != null && la in -90.0..90.0 && lo in -180.0..180.0) {
                            val p = GpxPoint(la, lo, ele, time)
                            when (k) {
                                Kind.WPT -> waypoints.add(GpxWaypoint(wptName, wptDesc, p))
                                else -> {
                                    curPoints.add(p)
                                    total++
                                    require(total <= maxPoints) { "GPX demasiado grande (> $maxPoints pontos)" }
                                }
                            }
                        }
                        kind = null
                    }
                    "trkseg" -> {
                        if (curPoints.isNotEmpty()) curSegments.add(GpxSegment(curPoints))
                        curPoints = ArrayList()
                        inSeg = false
                    }
                    "trk" -> {
                        if (curSegments.isNotEmpty()) tracks.add(GpxTrackData(curTrkName, curSegments))
                        curSegments = ArrayList()
                        inTrk = false
                    }
                    "rte" -> {
                        if (curPoints.isNotEmpty()) routes.add(GpxSegment(curPoints))
                        curPoints = ArrayList()
                        inRte = false
                    }
                }
            }
            event = parser.next()
        }
        return GpxData(docName, tracks, routes, waypoints)
    }

    /** Compatível com o resto da app: tracks (todos os segmentos) ou, se não houver, a primeira rota. */
    fun parse(input: InputStream): GpxTrack {
        val data = parseFull(input)
        var pts = data.tracks.flatMap { t -> t.segments.flatMap { it.points } }
        if (pts.size < 2) pts = data.routes.flatMap { it.points }
        val name = data.tracks.firstOrNull()?.name ?: data.name
        return GpxTrack(name, pts.map { GeoPoint(it.lat, it.lon, it.ele ?: 0.0) })
    }

    /** ISO 8601 -> milissegundos UTC (sem java.time, compatível com API 24). */
    fun parseTime(raw: String): Long? {
        val m = TIME_RE.matchEntire(raw.trim()) ?: return null
        val g = m.groupValues
        val cal = GregorianCalendar(TimeZone.getTimeZone("UTC"))
        cal.clear()
        cal.set(g[1].toInt(), g[2].toInt() - 1, g[3].toInt(), g[4].toInt(), g[5].toInt(), g[6].toInt())
        var ms = cal.timeInMillis
        if (g[7].isNotEmpty()) ms += g[7].padEnd(3, '0').take(3).toLong()
        val tz = g[8]
        if (tz.isNotEmpty() && tz != "Z") {
            val sign = if (tz[0] == '-') -1 else 1
            val digits = tz.substring(1).replace(":", "")
            val offsetMs = (digits.substring(0, 2).toLong() * 60 + digits.substring(2, 4).toLong()) * 60_000L
            ms -= sign * offsetMs
        }
        return ms
    }

    /** Escreve uma gravação em formato GPX 1.1. */
    fun write(name: String, points: List<TrackPointEntity>, out: OutputStream) {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<gpx version=\"1.1\" creator=\"My Steps\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n")
        sb.append("  <trk>\n    <name>").append(escape(name)).append("</name>\n    <trkseg>\n")
        for (p in points) {
            sb.append("      <trkpt lat=\"")
                .append(String.format(Locale.US, "%.7f", p.latitude))
                .append("\" lon=\"")
                .append(String.format(Locale.US, "%.7f", p.longitude))
                .append("\">")
            p.altitude?.let { sb.append("<ele>").append(String.format(Locale.US, "%.1f", it)).append("</ele>") }
            if (p.time > 0) sb.append("<time>").append(fmt.format(Date(p.time))).append("</time>")
            sb.append("</trkpt>\n")
        }
        sb.append("    </trkseg>\n  </trk>\n</gpx>\n")
        out.write(sb.toString().toByteArray(Charsets.UTF_8))
        out.flush()
    }

    private fun escape(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")
}
