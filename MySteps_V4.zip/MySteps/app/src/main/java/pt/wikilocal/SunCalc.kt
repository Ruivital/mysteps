package pt.wikilocal

import java.util.Calendar
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/** Posição do Sol (offline) para decidir se é dia ou noite no local onde estamos. */
object SunCalc {

    /** Elevação do Sol em graus (negativa = abaixo do horizonte). Precisão ~0,1°. */
    fun elevationDeg(lat: Double, lon: Double, millis: Long): Double {
        val d = millis / 86_400_000.0 - 10957.5                       // dias desde J2000
        val l = norm(280.460 + 0.9856474 * d)
        val g = Math.toRadians(norm(357.528 + 0.9856003 * d))
        val lambda = Math.toRadians(l + 1.915 * sin(g) + 0.020 * sin(2 * g))
        val eps = Math.toRadians(23.439 - 0.0000004 * d)
        val ra = atan2(cos(eps) * sin(lambda), cos(lambda))
        val dec = asin(sin(eps) * sin(lambda))
        val gmst = norm(280.46061837 + 360.98564736629 * d)
        val h = Math.toRadians(norm(gmst + lon) - Math.toDegrees(ra))
        val phi = Math.toRadians(lat)
        val elev = asin(sin(phi) * sin(dec) + cos(phi) * cos(dec) * cos(h))
        return Math.toDegrees(elev)
    }

    /** Noite = Sol a mais de 3° abaixo do horizonte (já escuro no mato). */
    fun isNight(lat: Double, lon: Double, millis: Long = System.currentTimeMillis()): Boolean =
        elevationDeg(lat, lon, millis) < -3.0

    /** Alternativa sem localização: pela hora local. */
    fun isNightByClock(): Boolean {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return h >= 20 || h < 7
    }

    private fun norm(deg: Double): Double = ((deg % 360.0) + 360.0) % 360.0
}
