package pt.wikilocal

import android.annotation.SuppressLint
import android.content.Context
import android.location.GnssStatus
import android.location.LocationManager
import android.os.Handler
import android.os.Looper

/** Conta os satélites visíveis / usados no fix (indicador de qualidade do sinal GPS). */
class GnssMonitor(context: Context) {

    private val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private var registered = false

    private val callback = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(status: GnssStatus) {
            var used = 0
            for (i in 0 until status.satelliteCount) if (status.usedInFix(i)) used++
            TrackerState.gnss.value = TrackerState.Gnss(used, status.satelliteCount)
        }

        override fun onStopped() {
            TrackerState.gnss.value = TrackerState.Gnss()
        }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun start() {
        if (registered) return
        try {
            registered = lm.registerGnssStatusCallback(callback, Handler(Looper.getMainLooper()))
        } catch (e: SecurityException) {
            registered = false
        }
    }

    fun stop() {
        if (!registered) return
        try {
            lm.unregisterGnssStatusCallback(callback)
        } catch (e: Exception) {
            // ignorar
        }
        registered = false
    }
}
