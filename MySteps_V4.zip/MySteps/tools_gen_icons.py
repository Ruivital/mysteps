#!/usr/bin/env python3
"""Gera ícones (legacy, round, adaptive, monochrome) e imagem da splash screen."""
import math, os
from PIL import Image, ImageDraw

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "app/src/main/res")
BASE = 1728            # 108 * 16 -> grelha adaptive (108dp) a 16 px/dp
K = BASE / 108.0

def bez(p0, p1, p2, p3, n=120):
    pts = []
    for i in range(n + 1):
        t = i / n
        x = (1-t)**3*p0[0] + 3*(1-t)**2*t*p1[0] + 3*(1-t)*t**2*p2[0] + t**3*p3[0]
        y = (1-t)**3*p0[1] + 3*(1-t)**2*t*p1[1] + 3*(1-t)*t**2*p2[1] + t**3*p3[1]
        pts.append((x, y))
    return pts

def foreground(mono=False):
    mode = "L" if mono else "RGBA"
    img = Image.new(mode, (BASE, BASE), 0 if mono else (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    C = (lambda rgba, m=255: m) if mono else (lambda rgba, m=255: rgba)
    S = lambda pts: [(x*K, y*K) for x, y in pts]

    # montanha de trás
    d.polygon(S([(22,76),(37,54),(52,76)]), fill=C((165,214,167,255)))
    # montanha da frente
    d.polygon(S([(30,76),(50,48),(60,62),(68,50),(86,76)]), fill=C((255,255,255,255)))
    # neve / sombra
    if not mono:
        d.polygon(S([(50,48),(44,57),(50,54),(54,57)]), fill=(224,242,241,255))
    # caminho sinuoso
    path = bez((34,78),(70,76),(36,64),(62,56))
    w = 3.4 * K
    for x, y in path:
        d.ellipse([x*K-w/2, y*K-w/2, x*K+w/2, y*K+w/2], fill=C((255,204,128,255)))
    # pino
    cx, cy, r = 62, 38, 10
    d.polygon(S([(cx-r*0.88, cy+r*0.5),(cx+r*0.88, cy+r*0.5),(cx, 58)]), fill=C((255,112,67,255)))
    d.ellipse([(cx-r)*K, (cy-r)*K, (cx+r)*K, (cy+r)*K], fill=C((255,112,67,255)))
    ir = 3.8
    d.ellipse([(cx-ir)*K, (cy-ir)*K, (cx+ir)*K, (cy+ir)*K], fill=0 if mono else (255,255,255,255))
    if mono:
        out = Image.new("RGBA", (BASE, BASE), (0, 0, 0, 0))
        out.putalpha(img)
        return out
    return img

def background():
    img = Image.new("RGBA", (BASE, BASE))
    px = img.load()
    top, bot = (67,160,71), (13,71,24)
    for y in range(BASE):
        t = y / (BASE - 1)
        c = tuple(int(top[i] + (bot[i]-top[i])*t) for i in range(3)) + (255,)
        for x in range(BASE):
            px[x, y] = c
    return img

def save(img, path, size):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.resize((size, size), Image.LANCZOS).save(path)

DENS = {"mdpi":1.0, "hdpi":1.5, "xhdpi":2.0, "xxhdpi":3.0, "xxxhdpi":4.0}
fg, bg, mono = foreground(), background(), foreground(mono=True)

# --- adaptive (108dp) + legacy (48dp)
legacy_full = Image.alpha_composite(bg, fg)
c0 = int(BASE * (108-72) / 2 / 108)
legacy_crop = legacy_full.crop((c0, c0, BASE-c0, BASE-c0))      # área visível 72dp
def mask(size, circle):
    m = Image.new("L", (size*4, size*4), 0)
    md = ImageDraw.Draw(m)
    if circle: md.ellipse([0,0,size*4-1,size*4-1], fill=255)
    else: md.rounded_rectangle([0,0,size*4-1,size*4-1], radius=int(size*4*0.22), fill=255)
    return m.resize((size, size), Image.LANCZOS)

for name, dens in DENS.items():
    ad = int(108*dens); lg = int(48*dens)
    d = f"{RES}/mipmap-{name}"
    save(fg,   f"{d}/ic_launcher_foreground.png", ad)
    save(bg,   f"{d}/ic_launcher_background.png", ad)
    save(mono, f"{d}/ic_launcher_monochrome.png", ad)
    for fn, circle in (("ic_launcher.png", False), ("ic_launcher_round.png", True)):
        im = legacy_crop.resize((lg, lg), Image.LANCZOS)
        im.putalpha(mask(lg, circle))
        os.makedirs(d, exist_ok=True); im.save(f"{d}/{fn}")

# --- splash (288dp, conteúdo dentro do círculo central de 192dp) — drawable-nodpi
os.makedirs(f"{RES}/drawable-nodpi", exist_ok=True)
fg.resize((864, 864), Image.LANCZOS).save(f"{RES}/drawable-nodpi/splash_icon.png")

# --- ícone Play Store 512
ps = legacy_full.resize((512, 512), Image.LANCZOS)
ps_full = Image.new("RGBA", (512,512)); ps_full.paste(ps, (0,0))
ps_full.save(os.path.join(os.path.dirname(RES), "..", "..", "..", "icon_playstore_512.png"))
print("imagens geradas")
